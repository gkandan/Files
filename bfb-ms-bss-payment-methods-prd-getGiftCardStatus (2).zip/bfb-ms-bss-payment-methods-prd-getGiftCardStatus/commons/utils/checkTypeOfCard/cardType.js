const cards = require('./cards');

function checkPattern(creditCardBin, pattern) {
  if (pattern instanceof RegExp) {
    return pattern.test(creditCardBin);
  }

  pattern = pattern.toString();
  return creditCardBin.substr(0, pattern.length) === pattern;
}

function checkRange(creditCardBin, [min, max]) {
  const length = min.toString().length;
  const value = parseInt(creditCardBin.substr(0, length));

  return value >= min && value <= max;
}

function checkCard(creditCardBin, pattern) {
  return Array.isArray(pattern)
    ? checkRange(creditCardBin, pattern)
    : checkPattern(creditCardBin, pattern);
}

function getBin(value) {
  return value.toString().replace(/\D/g, '').substr(0, 6);
}

function cardType(card) {
  const creditCardBin = getBin(card);
  const detectedTypes = [];

  cards.forEach(listCard => {
    listCard.pattern.forEach(pattern => {
      if (checkCard(creditCardBin, pattern)) {
        detectedTypes.unshift(listCard.name);
      }
    });
  });

  return detectedTypes[0] || '';
}

module.exports = cardType;
