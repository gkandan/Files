const {
  Logger,
} = require('@dtvgo-be/pkg_dtv_core');
const config = require('../../config');

module.exports = {
  success({
    message,
    custom = {},
  }) {

    Logger.sendEs({
      statusCode: 200,
      message,
      custom,
    }, config);
  },
  error({
    message,
    custom = {},
    error,
  }) {
    Logger.sendEs({
      statusCode: 200,
      message,
      custom,
      error,
    }, config);
  },
  info({
    message,
    custom = {},
    error,
  }) {
    Logger.sendEs({
      statusCode: 200,
      message,
      custom,
      error,
    }, config);
  },
};
