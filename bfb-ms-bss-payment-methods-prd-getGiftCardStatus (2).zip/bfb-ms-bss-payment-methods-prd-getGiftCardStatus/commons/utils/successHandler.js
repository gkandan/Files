const { ResponseHandler } = require('@dtvgo-be/pkg_dtv_core');

const responseHandler = data => {
  const resultHandler = { ...ResponseHandler.successHandler(data) };
  if (data.event.headers) {
    resultHandler.headers = {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Methods': '*',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': true,
      'Access-Control-Allow-Headers': '*',
      'Content-Length': '1688',
      ...(resultHandler.headers || {}),
    };
  }

  return resultHandler;
};

module.exports = {
  responseHandler,
};
