const RESPONSE_MESSAGES = {
  TYPE_OBJECT: 'PaymentMethod',
  TYPE_PAYMENT_METHOD: 'MerchantAcceptedPayment',
  CURRENCY: 'MXN',
  PAYMENT_TYPE: 'DirectCarrierBilling',
  NOTE: 'DirectCarrierBilling payment ID',
  COUNTRY: 'MX',
  PAYMENT_METHOD_CREDIT_CARD_TYPE: 'CreditCard',
  SUCCESSFULLY_CHANGED: 'successfully changed',
  INVALID_PARAMETER: 'Invalid Parameter',
  COUNTRY_OF_BR: 'BR',
  SOURCE_CHANNEL: 'DTV',
  RESPONSE_UNDEFINED: 'Internal Error / Bad Request / Timeout',
  INVALID_OR_EXPIRED_TOKEN: 'Invalid or expired token',
  INVALID_REQUEST: 'Invalid request',
  SUCCESS: 'Success',
  STATUS_NOT_FOUND: 'Request failed with status code 404',
  NO_ACCOUNT_MATCHES: 'No Account matches identifier',
  USER_READY_TO_CREATE: 'user ready to create payment method',
  ACCOUNT: 'Account',
  USER_ALREADY_EXISTS: 'user already exists, will not be able to create payment method',
  INTERNAL_SERVER_ERROR: 'Internal Error',
  NOT_PAID_MESSAGE: 'Suspended for failure to pay',
  NOT_PAID: 'Suspendido por falta de pago',
  RESPONSE_CODE_EEO: 'EE0',
  RESPONSE_CODE_EE1: 'EE1',
  SEND_SMS_WITH_SUCCESS: 'Send sms-token success',
  WITHOUT_CREDIT_CARD: 'The user does not have a credit card as a payment method',
  WITHOUT_PRIMARY_CREDIT_CARD: 'No primary card was found',
  EE0: 'EE0',
  EE1: 'EE1',
  ACTIVO: 'Activo',
  GIFT_CARD_NOT_BELONG_COUNTRY: 'This gift card number does not belong to this country',
  NO_CONNECTION_ON_DATABASE: 'There is no connection to the database.',
  FAIL_CONNECTION_MONGODB: 'Mongo failed to connect',
  STATUS_CODE_400: 400,
  INVALID_TOKEN: 'Invalid token',
  WITHOUT_PLUGIN_INFO: 'Without Plugin Info',
  MERCADO_PAGO_MISSING_PARAMETER: 'Missing parameter',
  MERCADO_PAGO_PRODUCT_NOT_FOUND: 'Product not found',
  MERCADO_PAGO_COUNTRY_NOT_SUPPORTED: 'Country not supported',
  MERCADO_PAGO_FAILED_TO_PARSE_USER_INFO: 'Failed to parse user info',
  MERCADO_PAGO_FAILED_TO_STORE_ORDER: 'Failed to store order',
  MERCADO_PAGO_PAYMENT_CALLBACK_STATUS_UPDATED: 'Status updated',
  MERCADO_PAGO_PAYMENT_CALLBACK_STATUS_ALREADY_UPDATED: 'Status already updated',
  MERCADO_PAGO_PAYMENT_CALLBACK_PREFERENCE_NOT_FOUND: 'Preference not found',
  BUSINESS_UNIT_IS_NOT_ALLOWED: 'Business unit is not allowed',
};

const MERCADO_PAGO_ERROR_STATUS = {
  PRODUCT_NOT_FOUND: 'E-001',
  GENERAL_ERROR: 'E-002',
  COUNTRY_NOT_SUPPORTED: 'E-003',
  FAILED_TO_PARSE_USER_INFO: 'E-004',
  FAILED_TO_STORE_ORDER: 'E-005',
  MISSING_PARAMETER: 'E-006',
  BUSINESS_UNIT_IS_NOT_ALLOWED: 'E-007',
};

const MERCADO_PAGO_PE_CHECKOUT_STATUS = {
  VALID: 'valid',
  INVALID: 'invalid',
};

const MERCADO_PAGO_CHECKOUT_STATUS = {
  PROCESSING: 'processing',
  COMPLETED: 'complete',
  FAILED: 'failed',
};

const REQUEST_PARAMS = {
  VINDICIA_OBJECT_CURRENCY_AMOUNT: 'CurrencyAmount',
};

const COUNTRY_CODES = {
  BR: 'BR',
};

const VINDICIA_CUSTOM_TAGS = {
  [COUNTRY_CODES.BR]: {
    FEDERAL_TAX_ID: 'vin:BrazilTax.federalTaxId',
  },
};

const BILLING_SYSTEMS = {
  VINDICIA: 'vindicia',
  KILLBILL: 'killbill',
};

const KILLBILL_ERROR_MESSAGES = {
  VALIDATION_ERROR: 'Error on payload validate for Killbill:',
};

const KILLBILL_MESSAGES = {
  GIFT_CARD_CODE: 'Gift Card Code: ',
};

const STEPS = {
  KILLBILL: {
    PAYMENT_CALLBACK: 'payment_callback',
    ADD_PAYMENT_METHOD: 'add_payment_method',
    GET_ACCOUNT_BY_EXTERNAL_ID: 'get_account_by_external_id',
    GET_PAYMENT_METHODS: 'get_payment_methods',
    CREATE_CREDIT: 'create_credit',
    GET_ACCOUNT_CREDIT: 'get_account_credit',
  },
  PAYMENT_ENGINE: {
    GENERATE_AUTH_TOKEN: 'generate_auth_token',
    CREATE_ZERO_AUTH: 'create_zero_auth',
  },
};

const STATUS_CODE = {
  PAYMENT_REQUIRED: 402,
};

const VENDOR_NAMES = {
  MERCADO_PAGO: 'MercadoPago',
};

const PROMISE_STATUS = {
  FULFILLED: 'fulfilled',
  REJECTED: 'rejected',
};

const PAYMENT_ENGINE_CHECKOUT = {
  ACTION_NAME: 'actionName',
  STORE: 'store',
  CHECKOUT_API_KEY: 'checkoutApiKey',
  COGNITO_CHECKOUT_AUTH_BASIC: 'cognitoCheckoutAuthBasic',
};

module.exports = {
  RESPONSE_MESSAGES,
  REQUEST_PARAMS,
  COUNTRY_CODES,
  VINDICIA_CUSTOM_TAGS,
  BILLING_SYSTEMS,
  KILLBILL_ERROR_MESSAGES,
  KILLBILL_MESSAGES,
  STEPS,
  STATUS_CODE,
  MERCADO_PAGO_ERROR_STATUS,
  MERCADO_PAGO_PE_CHECKOUT_STATUS,
  MERCADO_PAGO_CHECKOUT_STATUS,
  VENDOR_NAMES,
  PROMISE_STATUS,
  PAYMENT_ENGINE_CHECKOUT,
};
