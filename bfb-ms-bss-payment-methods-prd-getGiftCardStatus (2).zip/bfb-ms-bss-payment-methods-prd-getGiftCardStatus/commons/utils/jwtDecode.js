const jwtDecode = require('jwt-decode');

const jwtDecodeWrapper = ({
  enums: {
    RESPONSE_MESSAGES: {
      INVALID_TOKEN,
    },
  },
  CustomError,
  StatusCode: {
    NotFound,
  },
}) => {
  const decryptToken = token => {
    try {
      const decodedToken = jwtDecode(token);

      return decodedToken;
    } catch (error) {
      throw new CustomError({
        message: INVALID_TOKEN,
        statusCode: NotFound,
      });
    }
  };

  return {
    decryptToken,
  };
};


module.exports = jwtDecodeWrapper;
