const { Errors: { CustomError, StatusCode } } = require('@dtvgo-be/pkg_dtv_core');
const { errorHandler } = require('./errorHandler');
const { responseHandler } = require('./successHandler');
const enums = require('./enum');
const { responseCodes } = require('./incomm/messages');
const { upcMap } = require('./incomm/upcMap');
const logger = require('./logger');
const jwtDecodeWrapper = require('./jwtDecode');

const jwtDecode = jwtDecodeWrapper({ enums, CustomError, StatusCode });

module.exports = {
  errorHandler,
  responseHandler,
  enums,
  responseCodes,
  upcMap,
  logger,
  jwtDecode,
};
