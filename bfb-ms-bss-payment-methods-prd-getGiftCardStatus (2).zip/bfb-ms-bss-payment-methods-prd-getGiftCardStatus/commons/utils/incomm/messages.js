const responseCodes = {
  default: 'This code is not valid. Please check and try again.',
  10: {
    responseText: 'Invalid XML',
    Description: 'The XML is not formatted correctly or is missing a tag.',
    statusCode: 400,
  },
  11: {
    responseText: 'Invalid Signature',
    Description: 'The header auth signature is incorrect.',
    statusCode: 400,
  },
  '11b': {
    responseText: 'Invalid Terminal',
    Description: 'Transactions are not permitted from this terminal.',
    statusCode: 500,
  },
  12: {
    responseText: 'Invalid Merchant',
    // eslint-disable-next-line max-len
    Description: 'The card is assigned to a different merchant, or the merchant is not configured in the authorizing platform.',
    statusCode: 500,
  },
  13: {
    responseText: 'Invalid Location',
    Description: 'Transactions are not permitted from this location.',
    statusCode: 500,
  },
  14: {
    responseText: 'Routing Error',
    Description: 'The transaction failed due to an internal ROUTING ERROR.',
    statusCode: 500,
  },
  15: {
    responseText: 'Network Error',
    Description: 'This transaction failed due to a NETWORK ERROR.',
    statusCode: 500,
  },
  16: {
    responseText: 'Database Error',
    Description: 'This transaction failed due to a DATABASE ERROR.',
    statusCode: 500,
  },
  17: {
    responseText: 'Invalid Product Code',
    Description: 'This transaction failed due to an INVALID PRODUCT CODE.',
    statusCode: 401,
  },
  18: {
    responseText: 'Invalid UPC',
    Description: 'The UPC in the transaction is either NULL or INVALID.',
    statusCode: 401,
  },
  19: {
    responseText: 'No PIN Available',
    Description: 'There is no PIN available. The transaction failed.',
    statusCode: 401,
  },
  20: {
    responseText: 'Invalid PIN',
    Description: 'The transaction failed due to an INVALID PIN.',
    statusCode: 401,
  },
  21: {
    responseText: 'Invalid Amount',
    Description: 'The transaction failed due to an INVALID AMOUNT.',
    statusCode: 401,
  },
  22: {
    responseText: 'Invalid MIN',
    Description: 'The transaction failed due to an INVALID MIN.',
    statusCode: 401,
  },
  23: {
    responseText: 'Invalid VAN16',
    Description: 'The transaction failed because an INVALID VAN16 was supplied in the request.',
    statusCode: 500,
  },
  24: {
    responseText: 'Invalid Serial Number',
    Description: 'The transaction failed because an INVALID SERIAL NUMBER was supplied in the request.',
    statusCode: 401,
  },
  25: {
    responseText: 'Invalid ESN',
    Description: 'The transaction failed because an INVALID ESN was supplied in the request.',
    statusCode: 401,
  },
  26: {
    responseText: 'Vendor Application Error',
    Description: 'The transaction failed due to a VENDOR APPLICATION ERROR.',
    statusCode: 500,
  },
  27: {
    responseText: 'Vendor System Error',
    Description: 'The transaction failed due to a VENDOR SYSTEM ERROR.',
    statusCode: 500,
  },
  28: {
    responseText: 'Declined',
    Description: 'This transaction is DECLINED.',
    statusCode: 401,
  },
  29: {
    responseText: 'System Error',
    Description: 'This transaction failed due to a SYSTEM ERROR.',
    statusCode: 500,
  },
  31: {
    responseText: 'Already Inactive',
    Description: 'The card is already in an INACTIVE status.',
    statusCode: 401,
  },
  32: {
    responseText: 'Invalid Request',
    Description: 'The transaction failed due to an INVALID REQUEST.',
    statusCode: 400,
  },
  33: {
    responseText: 'Invalid Permission',
    Description: 'The transaction failed due to INVALID PERMISSION.',
    statusCode: 401,
  },
  34: {
    responseText: 'Invalid ZIP Code',
    Description: 'The transaction failed due to INVALID ZIP CODE.',
    statusCode: 400,
  },
  35: {
    responseText: 'Null Request',
    Description: 'The transaction failed due to NULL REQUEST.',
    statusCode: 400,
  },
  36: {
    responseText: 'Null Request Route',
    Description: 'The transaction failed due to NULL REQUEST ROUTE.',
    statusCode: 400,
  },
  37: {
    responseText: 'Null Request Category',
    Description: 'The transaction failed due to NULL REQUEST CATEGORY.',
    statusCode: 400,
  },
  38: {
    responseText: 'Card Redeemed',
    Description: 'The card has ALREADY been REDEEMED.',
    statusCode: 401,
  },
  39: {
    responseText: 'Invalid Track2 In Request',
    Description: 'Invalid Track2 In request.',
    statusCode: 500,
  },
  40: {
    responseText: 'Invalid UserID or Password',
    Description: 'Either the User ID or the Password is invalid.',
    statusCode: 500,
  },
  41: {
    responseText: 'PIN Not Sold',
    Description: 'The PIN you used was never sold. The transaction failed.',
    statusCode: 401,
  },
  42: {
    responseText: 'PIN Already Sold',
    Description: 'The PIN you used had already been sold. The transaction failed.',
    statusCode: 401,
  },
  43: {
    responseText: 'Invalid Card',
    Description: 'The card is INVALID.',
    statusCode: 401,
  },
  44: {
    responseText: 'Card Expired',
    Description: 'The card status is EXPIRED.',
    statusCode: 401,
  },
  45: {
    responseText: 'ESN Already Active',
    Description: 'The ESN is already active.',
    statusCode: 401,
  },
  46: {
    responseText: 'Card Deactivated',
    Description: 'The card has been DEACTIVATED.',
    statusCode: 401,
  },
  47: {
    responseText: 'Card Stolen',
    Description: 'The card status is STOLEN.',
    statusCode: 401,
  },
  48: {
    responseText: 'Card Lost',
    Description: 'The card status is LOST.',
    statusCode: 401,
  },
  49: {
    responseText: 'Card Damaged',
    Description: 'The card is DAMAGED.',
    statusCode: 401,
  },
  50: {
    responseText: 'Card Suspended',
    Description: 'The card has been SUSPENDED.',
    statusCode: 401,
  },
  51: {
    responseText: 'Insufficient Funds',
    Description: 'Cannot process request due to INSUFFICIENT FUNDS.',
    statusCode: 500,
  },
  52: {
    responseText: 'Card Pending',
    Description: 'The card status is PENDING.',
    statusCode: 401,
  },
  55: {
    responseText: 'Pin Redeemed',
    Description: 'The PIN has been REDEEMED.',
    statusCode: 401,
  },
  56: {
    responseText: 'ESN Deactivated',
    Description: 'The ESN handset has been DEACTIVATED.',
    statusCode: 401,
  },
  57: {
    responseText: 'Invalid or Inactive Pin',
    Description: 'The transaction failed because the PIN was either INVALID or INACTIVE.',
    statusCode: 401,
  },
  58: {
    responseText: 'Account is not Active',
    Description: 'The Account is NOT ACTIVE.',
    statusCode: 500,
  },
  59: {
    responseText: 'Invalid Account',
    Description: 'The transaction failed because an INVALID ACCOUNT was supplied in the request.',
    statusCode: 500,
  },
  60: {
    responseText: 'Account in Use',
    Description: 'The transaction failed because the account is IN USE.',
    statusCode: 401,
  },
  61: {
    responseText: 'Account Status Error',
    Description: 'The transaction failed due to an ACCOUNT STATUS ERROR.',
    statusCode: 401,
  },
  62: {
    responseText: 'Account Suspended',
    Description: 'The account has been SUSPENDED.',
    statusCode: 500,
  },
  63: {
    responseText: 'Account Expired',
    Description: 'The account status is EXPIRED.',
    statusCode: 500,
  },
  64: {
    responseText: 'Card in Use',
    Description: 'The transaction failed because the card is IN USE.',
    statusCode: 401,
  },
  65: {
    responseText: 'No Previous Active',
    Description: 'NO PREVIOUS ACTION was performed on the card.',
    statusCode: 401,
  },
  67: {
    responseText: 'Not Reversible',
    Description: 'The card is NOT REVERSIBLE.',
    statusCode: 401,
  },
  68: {
    responseText: 'Time Limit Expired',
    Description: 'The card is valid only for a limited time, and the time limit has been reached.',
    statusCode: 401,
  },
  69: {
    responseText: 'Original Transaction Not Found',
    Description: 'The reversal transaction failed because the original transaction was NOT FOUND.',
    statusCode: 401,
  },
  70: {
    responseText: 'Maximum Balance Limitation',
    Description: 'The transaction failed because it would cause the card to exceed the MAXIMUM BALANCE LIMITATION.',
    statusCode: 401,
  },
  71: {
    responseText: 'Invalid Promotion',
    Description: 'The transaction failed due to INVALID PROMOTION.',
    statusCode: 401,
  },
  72: {
    responseText: 'Marshaling Error',
    Description: 'The transaction failed due to a MARSHALLING ERROR',
    statusCode: 401,
  },
  73: {
    responseText: 'Incorrect Card Status',
    Description: 'The transaction failed due to an INCORRECT CARD STATUS.',
    statusCode: 401,
  },
  74: {
    responseText: 'Card Not Active',
    Description: 'The card is NOT ACTIVE.',
    statusCode: 401,
  },
  75: {
    responseText: 'No Authorization Number',
    Description: 'No Authorization Number.',
    statusCode: 400,
  },
  76: {
    responseText: 'Maximum Recharges Exceeded',
    Description: 'The Maximum Recharges EXCEEDED for the card',
    statusCode: 500,
  },
  77: {
    responseText: 'Card Already Issued',
    Description: 'The card has already been ISSUED.',
    statusCode: 401,
  },
  78: {
    responseText: 'Card Not Issued',
    Description: 'The card has NOT been ISSUED.',
    statusCode: 401,
  },
  79: {
    responseText: 'Pin Locked',
    Description: 'The PIN is LOCKED.',
    statusCode: 401,
  },
  80: {
    responseText: 'Maximum Redemptions Exceeded',
    Description: 'The Maximum Redemption EXCEEDED for the card.',
    statusCode: 401,
  },
  81: {
    responseText: 'Invalid Currency Code',
    Description: 'The transaction failed due to an INVALID CURRENCY CODE.',
    statusCode: 401,
  },
  82: {
    responseText: 'Invalid Issuer Identity Number',
    Description: 'The transaction failed due to an INVALID ISSUER IDENTITY NUMBER.',
    statusCode: 401,
  },
  83: {
    responseText: 'Suspected Fraud',
    Description: 'The transaction failed due to SUSPECTED FRAUD.',
    statusCode: 401,
  },
  84: {
    responseText: 'Format Error',
    Description: 'The transaction failed due to a FORMAT ERROR.',
    statusCode: 400,
  },
  85: {
    responseText: 'Duplicate Request',
    Description: 'This is a DUPLICATE REQUEST.',
    statusCode: 401,
  },
  87: {
    responseText: 'Action Already Executed',
    Description: 'The action in the request has ALREADY been EXECUTED.',
    statusCode: 401,
  },
  88: {
    responseText: 'Invalid Amount For Already Denominated Card',
    // eslint-disable-next-line max-len
    Description: 'The card is valid only for certain denominations. You specified an amount that is not valid for the card.',
    statusCode: 401,
  },
  89: {
    responseText: 'Already Redeemed',
    Description: 'The card has ALREADY been REDEEMED.',
    statusCode: 401,
  },
  90: {
    responseText: 'Action Not Supported',
    Description: 'This action is NOT SUPPORTED.',
    statusCode: 401,
  },
  91: {
    responseText: 'Service Provider Connection Timeout',
    Description: 'Service Provider Connection Timeout.',
    statusCode: 500,
  },
  92: {
    responseText: 'Unable to Route Transaction',
    Description: 'Unable to Route Transaction.',
    statusCode: 500,
  },
  93: {
    responseText: 'Service Provider Read Timeout',
    Description: 'Service Provider Read Timeout.',
    statusCode: 500,
  },
  94: {
    responseText: 'Issuer Disabled',
    Description: 'The Issuer is DISABLED.',
    statusCode: 401,
  },
  95: {
    responseText: 'Time Limit Exceeded',
    Description: 'The card is valid only for a limited time, and the time limit has been reached.',
    statusCode: 401,
  },
  96: {
    responseText: 'Recharge in Progress',
    Description: 'Recharge is IN PROGRESS.',
    statusCode: 401,
  },
  97: {
    responseText: 'Recharge not Supported',
    Description: 'Recharge is NOT SUPPORTED for the card in the request.',
    statusCode: 401,
  },
  98: {
    responseText: 'MIN Check Unsupported',
    Description: 'MIN check is not supported for the card in the request.',
    statusCode: 401,
  },
  99: {
    responseText: 'Card Not In Inventory',
    Description: 'The card is NOT in the INVENTORY.',
    statusCode: 401,
  },
  100: {
    responseText: 'Card Returned',
    Description: 'The card is in a RETURNED status.',
    statusCode: 401,
  },
  101: {
    responseText: 'Not Redeemed',
    Description: 'The card is not REDEEMED. The transaction failed.',
    statusCode: 401,
  },
  102: {
    responseText: 'Card Disabled',
    Description: 'This card status is DISABLED.',
    statusCode: 401,
  },
  103: {
    responseText: 'Card Retired',
    Description: 'This card status is RETIRED.',
    statusCode: 401,
  },
  104: {
    responseText: 'Card Used',
    Description: 'This card status is USED.',
    statusCode: 401,
  },
  105: {
    responseText: 'Last Transaction Voided Already',
    Description: 'The last transaction was already VOIDED.',
    statusCode: 401,
  },
  106: {
    responseText: 'Not Logged On',
    Description: 'You are not logged on.',
    statusCode: 500,
  },
  107: {
    responseText: 'Service Provider Network IO Error',
    Description: 'Service Provider Network IO Error.',
    statusCode: 500,
  },
  108: {
    responseText: 'Service Provider Invalid Response',
    Description: 'Service Provider Invalid Response.',
    statusCode: 401,
  },
  109: {
    responseText: 'Card Actions Suspended',
    Description: 'All actions on this card are SUSPENDED.',
    statusCode: 401,
  },
  112: {
    responseText: 'Can NOT refund this card, card has been RECHARGED',
    Description: 'This card has been RECHARGED, and therefore cannot be refunded.',
    statusCode: 401,
  },
  113: {
    responseText: 'Recharge minutes requested would cause card to exceed max allowable card balance',
    // eslint-disable-next-line max-len
    Description: 'The number of RECHARGE minutes you requested would cause the card balance to exceed the maximum allowed.',
    statusCode: 401,
  },
  114: {
    // eslint-disable-next-line max-len
    responseText: 'Can NOT void this recharge due to insufficient balance on card OR can NOT void-a-recharge on a card in use.',
    // eslint-disable-next-line max-len
    Description: 'This recharge can NOT be voided, because either the balance on the card is insufficient or the card is in use.',
    statusCode: 401,
  },
  115: {
    responseText: 'Can NOT refund individual SAMS MULTIPACK card',
    Description: 'Can NOT refund individual SAMS MULTIPACK card.',
    statusCode: 401,
  },
  116: {
    responseText: 'Can NOT recharge an entire MULTIPACK',
    Description: 'Can NOT recharge an entire MULTIPACK.',
    statusCode: 401,
  },
  117: {
    responseText: 'Can NOT void-a-recharge on an entire MULTIPACK',
    Description: 'Can NOT void a recharge on an entire MULTIPACK.',
    statusCode: 401,
  },
  118: {
    responseText: 'Can NOT recharge OR void-a-recharge on a non-rechargeable card',
    Description: 'Can NOT recharge or void a recharge on a non-rechargeable card.',
    statusCode: 401,
  },
  119: {
    responseText: 'Maximum Transactions Exceeded',
    Description: 'The card has reached the maximum number of transactions.',
    statusCode: 401,
  },
  120: {
    responseText: 'Invalid Source Card Status',
    Description: 'The card status is INVALID SOURCE.',
    statusCode: 401,
  },
  121: {
    responseText: 'Invalid Target Card Status',
    Description: 'The card status is INVALID TARGET.',
    statusCode: 401,
  },
  143: {
    responseText: 'Card Locked',
    Description: 'The card is LOCKED.',
    statusCode: 401,
  },
  145: {
    responseText: 'Card Already Locked',
    Description: 'The card is ALREADY LOCKED.',
    statusCode: 401,
  },
  170: {
    responseText: 'Failure',
    Description: 'The transaction failed.',
    statusCode: 401,
  },
  180: {
    responseText: 'Transaction Amount Exceeds the Maximum Limit',
    Description: 'The transaction amount exceeds the maximum. The transaction failed.',
    statusCode: 401,
  },
  181: {
    responseText: 'Transaction Amount Below the Minimum Limit',
    Description: 'The transaction amount is less than the minimum. The transaction failed.',
    statusCode: 401,
  },
  182: {
    responseText: 'Registration Declined because OFAC Verification Failed',
    Description: 'Registration was declined because OFAC Verification failed.',
    statusCode: 401,
  },
  183: {
    responseText: 'Registration failed because request Exceeds Daily Card Purchase Limit',
    Description: 'Registration failed because the request exceeds the daily card purchase limit.',
    statusCode: 401,
  },
  184: {
    responseText: 'Registration failed because request Exceeds Maximum Card Purchase Limit Per Account',
    Description: 'Registration failed because the request exceeds the maximum card purchase limit per account.',
    statusCode: 401,
  },
  216: {
    responseText: 'Database error during success post processing',
    Description: 'Database error during success post processing.',
    statusCode: 500,
  },
  229: {
    responseText: 'System error during success post processing',
    Description: 'System error during success post processing.',
    statusCode: 500,
  },
  1293: {
    responseText: 'CashOut Amount Failure',
    Description: 'CashOut amount failure.',
    statusCode: 401,
  },
  4002: {
    responseText: 'Card is Deactive',
    Description: 'The card has been DEACTIVATED.',
    statusCode: 401,
  },
  4003: {
    responseText: 'Card is Redeemed',
    Description: 'The card has ALREADY been REDEEMED.',
    statusCode: 401,
  },
  4004: {
    responseText: 'Card is Pending',
    Description: 'The card status is PENDING.',
    statusCode: 401,
  },
  4005: {
    responseText: 'Card is Suspended',
    Description: 'The card has been SUSPENDED.',
    statusCode: 401,
  },
  4006: {
    responseText: 'Card Not Found',
    Description: 'The card was NOT FOUND in the InComm database.',
    statusCode: 401,
  },
  4007: {
    responseText: 'Card is Expired',
    Description: 'The card status is EXPIRED.',
    statusCode: 401,
  },
  4008: {
    responseText: 'Card is Stolen',
    Description: 'The card status is STOLEN.',
    statusCode: 401,
  },
  4009: {
    responseText: 'Card is Lost',
    Description: 'The card status is LOST.',
    statusCode: 401,
  },
  4010: {
    responseText: 'Card is Damaged',
    Description: 'The card is DAMAGED.',
    statusCode: 401,
  },
};

module.exports = { responseCodes };
