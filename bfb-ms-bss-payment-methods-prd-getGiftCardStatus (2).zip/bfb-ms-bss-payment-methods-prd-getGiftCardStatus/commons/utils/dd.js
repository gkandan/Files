const tracer = require('dd-trace').init();

const setDdTag = (description, data) => {
  const span = tracer.scope().active();

  if (span) {
    span.setTag(description, data);
  }
};

module.exports = {
  setDdTag,
};
