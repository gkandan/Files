const { ResponseHandler } = require('@dtvgo-be/pkg_dtv_core');

const errorHandler = data => {
  const resultHandler = { ...ResponseHandler.errorHandler(data) };
  if (data.event.headers) {
    resultHandler.headers = {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': '*',
      'Access-Control-Allow-Credentials': true,
      'Access-Control-Allow-Headers': '*',
      'Content-Length': '1688',
      ...(resultHandler.headers || {}),
    };
  }

  return resultHandler;
};

module.exports = { errorHandler };
