const { Errors: { StatusCode } } = require('@dtvgo-be/pkg_dtv_core');

const getHttpStatusCode = (data, defaultCode = StatusCode.InternalServerError) => {
  const statusCode = data?.statusCode || data?.response?.statusCode || data?.response?.status || defaultCode;
  return statusCode;
};

const handleForbiddenError = statusCode => {
  if (statusCode === 403) {
    return 423;
  }

  return statusCode;
};

const stringReplacer = (string, msg) => string.replace('{msg}', msg);

const errorMessageHandler = (defaultErrorMessage, error) => stringReplacer(defaultErrorMessage, error.response?.data?.error?.message
  || error.response?.data?.message || 'an error ocurred');

module.exports = {
  getHttpStatusCode,
  errorMessageHandler,
  handleForbiddenError,
};
