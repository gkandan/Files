const killBillService = ({
  axios,
  CustomError,
  errorMessageHandler,
  getHttpStatusCode,
  config: { applicationName, killbill },
  enums: {
    STEPS: {
      KILLBILL,
    },
    KILLBILL_MESSAGES: {
      GIFT_CARD_CODE,
    },
  },
}) => {
  const errorMessage = 'Error in Killbill service {step} step: {msg}';

  const replaceStep = (string, step) => string.replace('{step}', step);

  const getGiftCardFromDescription = description => description.split(GIFT_CARD_CODE)[1];

  const buildCustomError = ({ step, error }) => new CustomError({
    message: errorMessageHandler(replaceStep(errorMessage, step), error),
    additionalData: {
      ...error.additionalData,
      step,
    },
    error: error.response?.data,
    statusCode: getHttpStatusCode(error),
  });

  const buildRequestObject = ({
    apikey, apisecrets, username, password,
  }, giftCardCode = null) => {
    const authorization = Buffer.from(`${username}:${password}`).toString('base64');

    const requestObject = {
      requestConfig: {
        headers: {
          accept: 'application/json',
          'X-Killbill-CreatedBy': applicationName,
          authorization: `Basic ${authorization}`,
          'X-Killbill-ApiKey': apikey,
          'X-Killbill-ApiSecret': apisecrets,
          'Content-Type': 'application/json',
          ...(giftCardCode && { 'X-Killbill-Reason': `GIFTCARD SELFCARE ${giftCardCode}` }),
        },
      },
      killbillUrl: killbill.endpoint,
      killbillUrlCallback: killbill.callbackEndpoint,
    };

    return requestObject;
  };

  const paymentCallback = async (payload, killBillCredentials) => {
    try {
      const { killbillUrlCallback, requestConfig } = buildRequestObject(killBillCredentials);

      const url = `${killbillUrlCallback}/api/msbillingccpayment/credit-card/callback-payment`;
      const { data } = await axios.request({
        ...requestConfig,
        url,
        method: 'post',
        data: {
          ...payload,
          gateway: payload.gateway || '',
        },
      });

      return { data };
    } catch (error) {
      if (error?.response) {
        throw buildCustomError({ step: KILLBILL.PAYMENT_CALLBACK, error });
      }
      throw error;
    }
  };

  const addAPaymentMethod = async (accountId, data, killBillCredentials) => {
    try {
      const { killbillUrl, requestConfig } = buildRequestObject(killBillCredentials);
      const params = {
        isDefault: true,
        payAllUnpaidInvoices: true,
      };

      const response = await axios.request({
        ...requestConfig,
        params,
        url: `${killbillUrl}/1.0/kb/accounts/${accountId}/paymentMethods`,
        method: 'post',
        data,
      });

      return response.data;

    } catch (error) {
      if (error?.response) {
        throw buildCustomError({ step: KILLBILL.ADD_PAYMENT_METHOD, error });
      }
      throw error;
    }
  };

  const getAccountByExternalId = async (externalKey, killBillCredentials) => {
    try {
      const { killbillUrl, requestConfig } = buildRequestObject(killBillCredentials);

      const response = await axios.request({
        ...requestConfig,
        url: `${killbillUrl}/1.0/kb/accounts/?externalKey=${externalKey}`,
        method: 'get',
      });

      return response.data;

    } catch (error) {
      if (error?.response) {
        throw buildCustomError({ step: KILLBILL.GET_ACCOUNT_BY_EXTERNAL_ID, error });
      }
      throw error;
    }
  };

  const getPaymentMethods = async (accountId, killBillCredentials) => {
    try {
      const { killbillUrl, requestConfig } = buildRequestObject(killBillCredentials);

      const response = await axios.request({
        ...requestConfig,
        url: `${killbillUrl}/1.0/kb/accounts/${accountId}/paymentMethods?withPluginInfo=true`,
        method: 'get',
      });

      return response.data;

    } catch (error) {
      if (error?.response) {
        throw buildCustomError({ step: KILLBILL.GET_PAYMENT_METHODS, error });
      }
      throw error;
    }
  };

  const createCredit = async ({ creditsArray, killBillCredentials }) => {
    try {
      const [{ description }] = creditsArray;
      const giftCardCode = getGiftCardFromDescription(description);

      const { killbillUrl, requestConfig } = buildRequestObject(killBillCredentials, giftCardCode);

      const url = `${killbillUrl}/1.0/kb/credits?autoCommit=true`;
      const { data } = await axios.request({
        ...requestConfig,
        url,
        method: 'post',
        data: creditsArray,
      });

      return data;
    } catch (error) {
      if (error?.response) {
        throw buildCustomError({ step: KILLBILL.CREATE_CREDIT, error });
      }
      throw error;
    }
  };

  const getAccountCredit = async (externalAccountId, killBillCredentials) => {
    try {
      const { killbillUrl, requestConfig } = buildRequestObject(killBillCredentials);

      const response = await axios.request({
        ...requestConfig,
        url: `${killbillUrl}/1.0/kb/accounts?externalKey=${externalAccountId}&accountWithBalance=true`,
        method: 'get',
      });

      return response.data;

    } catch (error) {
      if (error?.response) {
        throw buildCustomError({ step: KILLBILL.GET_ACCOUNT_CREDIT, error });
      }
      throw error;
    }
  };

  return {
    addAPaymentMethod,
    getPaymentMethods,
    getAccountByExternalId,
    paymentCallback,
    createCredit,
    getAccountCredit,
  };
};

module.exports = killBillService;
