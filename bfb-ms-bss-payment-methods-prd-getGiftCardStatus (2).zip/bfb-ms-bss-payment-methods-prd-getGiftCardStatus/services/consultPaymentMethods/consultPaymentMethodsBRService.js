const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const consultPaymentMethodsBRService = ({
  axios,
  CustomError,
}) => {
  const errorMessage = 'Error on consult payment-methods: {msg}';

  const getPaymentMethodInAccount = async (accountId, config) => {
    const {
      token,
      url,
      timeout,
    } = config;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          Authorization: `Basic ${token}`,
          'cache-control': 'no-cache',
          'content-type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const response = await instance.get(`/accounts/${accountId}`);
      return response.data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    getPaymentMethodInAccount,
  };
};

module.exports = consultPaymentMethodsBRService;
