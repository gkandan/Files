const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const giftCardStatusDGoValidator = ({ CustomError }) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const validateGiftCard = async (giftCardNumber, dbConfigs, repository, db) => {
    try {
      await db.connect(dbConfigs.uri, dbConfigs.dbName);

      const data = await repository.gift.findOne({
        pin: giftCardNumber,
        redeem: true,
      }, { _id: true });

      return data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    validateGiftCard,
  };
};

module.exports = giftCardStatusDGoValidator;
