const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const giftCardStatusDGoRecorder = ({
  CustomError,
  logger,
}) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const recorderGiftCard = async (
    payload,
    dbConfigs,
    repository,
    db,
    giftCardPartnerRedeem,
  ) => {

    const dateTime = new Date();

    const data = {
      $set: {
        pin: payload.giftCardNumber,
        transactionId: payload.transactionId,
        vindiciaId: payload.vindiciaId,
        redeem: false,
        responseText: payload.responseText,
        updated_at: dateTime,
      },
      $setOnInsert: {
        created_at: dateTime,
      },
    };

    if (giftCardPartnerRedeem) {
      data.$set.responseText = giftCardPartnerRedeem.RetailTransactionTVResponse.responseText;
      data.$set.denom = giftCardPartnerRedeem.RetailTransactionTVResponse.productResp
        .inventoryRespInfo.denom;
      data.$set.faceValue = giftCardPartnerRedeem.RetailTransactionTVResponse.productResp
        .inventoryRespInfo.faceValue;
      data.$set.snapshot = giftCardPartnerRedeem;
      data.$set.redeem = true;
      data.$set.ActivationDateTime = dateTime;
    }


    try {
      await db.connect(dbConfigs.uri, dbConfigs.dbName);

      await repository.gift.createOrUpdateWithWhere(
        {
          pin: payload.giftCardNumber,
          transactionId: payload.transactionId,
        },
        data,
      );

      const result = await repository.gift.findOne({
        pin: payload.giftCardNumber,
        transactionId: payload.transactionId,
      });

      logger.success({
        message: 'GIFT CARD MONGODB',
        custom: result,
      });

    } catch (error) {

      logger.error({
        message: 'GIFT CARD MONGODB ERROR',
        custom: { ...data.$set },
        error,
      });

      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    recorderGiftCard,
  };
};

module.exports = giftCardStatusDGoRecorder;
