const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const vindiciaAccount = ({
  axios,
  CustomError,
}) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods: {msg}';

  const updateCustomFields = async (accountId, metadata, config) => {
    const {
      token,
      url,
      timeout,
    } = config;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          'cache-control': 'no-cache',
          'content-type': 'application/json',
          Authorization: `Basic ${token}`,
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const { data } = await instance.post(`/accounts/${accountId}`, {
        metadata,
      });

      return data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    updateCustomFields,
  };
};

module.exports = vindiciaAccount;
