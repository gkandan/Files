const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const getAccountVindiciaService = ({
  axios,
  CustomError,
}) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const getAccount = async (accountId, config) => {
    const {
      token,
      url,
      timeout,
    } = config;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          Authorization: `Basic ${token}`,
          'cache-control': 'no-cache',
          'content-type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const { data } = await instance.get(`accounts/${accountId}`);

      return data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    getAccount,
  };
};

module.exports = getAccountVindiciaService;
