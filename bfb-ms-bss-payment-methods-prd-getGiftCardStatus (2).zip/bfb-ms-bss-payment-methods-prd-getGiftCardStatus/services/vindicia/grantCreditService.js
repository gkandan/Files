const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const grantCreditVindiciaService = ({
  axios,
  CustomError,
}) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const postGrantCredit = async (accountId, body, config) => {
    const {
      token,
      url,
      timeout,
    } = config;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          Authorization: `Basic ${token}`,
          'cache-control': 'no-cache',
          'content-type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const { data } = await instance.post(`accounts/${accountId}/currency_amount_changes`, body);

      return data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    postGrantCredit,
  };
};

module.exports = grantCreditVindiciaService;
