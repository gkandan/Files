const attPaymentMethodsService = ({
  axios,
  CustomError,
}) => {

  const attPaymentMethods = async (body, config) => {
    const {
      token,
      url,
      timeout,
    } = config;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          Authorization: `Basic ${token}`,
          'cache-control': 'no-cache',
          'content-type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const response = await instance.post('/payment_methods', body);
      return response.data;
    } catch (error) {
      throw new CustomError({
        message: `${error.message}`,
        error,
        statusCode: error.serviceStatusCode,
      });
    }
  };

  return {
    attPaymentMethods,
  };
};

module.exports = attPaymentMethodsService;

