const axios = require('axios');
const { Errors: { CustomError, StatusCode } } = require('@dtvgo-be/pkg_dtv_core');
const config = require('../config');
const factory = require('./factory');
const { logger, enums, jwtDecode } = require('../commons/utils');
const { errorMessageHandler, getHttpStatusCode } = require('../commons/utils/utility');
const secretManager = require('../commons/lib/secretManager')({});

const dependencies = {
  config,
  axios,
  CustomError,
  StatusCode,
  logger,
  enums,
  errorMessageHandler,
  getHttpStatusCode,
  jwtDecode,
  secretManager,
};

module.exports = factory(dependencies);
