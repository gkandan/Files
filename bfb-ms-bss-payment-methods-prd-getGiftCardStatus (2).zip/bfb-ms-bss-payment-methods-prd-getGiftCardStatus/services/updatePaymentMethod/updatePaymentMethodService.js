const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const updatePaymentMethodService = ({
  axios,
  CustomError,
}) => {
  const errorMessage = 'Error on update-payment-method: {msg}';

  const updatePaymentMethod = async (accountId, body, config) => {
    const {
      token,
      url,
      timeout,
    } = config;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          Authorization: `Basic ${token}`,
          'cache-control': 'no-cache',
          'Content-Type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const response = await instance
        .post(`/accounts/${accountId}?update_behavior=CatchUp&replace_on_all_subscriptions=true&ignore_avs=false&ignore_cvn=false`, body);
      return response.data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    updatePaymentMethod,
  };
};

module.exports = updatePaymentMethodService;
