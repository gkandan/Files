

const paymentEngineService = ({
  axios,
  CustomError,
  errorMessageHandler,
  getHttpStatusCode,
  config: { paymentEngine },
  enums: {
    STEPS: {
      PAYMENT_ENGINE,
    },
    STATUS_CODE,
  },
}) => {
  const errorMessage = 'Error in Payment Engine service {step} step: {msg}';

  const replaceStep = (string, step) => string.replace('{step}', step);

  const buildCustomError = ({ step, error }) => new CustomError({
    message: errorMessageHandler(replaceStep(errorMessage, step), error),
    additionalData: {
      ...error.additionalData,
      step,
      error: error.response?.data,
    },
    statusCode: getHttpStatusCode(error),
  });

  const buildRequestObject = ({
    apikey, username, password, authorization, contentType,
  }) => {
    const auth = authorization
      || `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`;

    const requestObject = {
      requestConfig: {
        headers: {
          accept: 'application/json',
          'Content-Type': contentType || 'application/json',
          'x-api-key': apikey,
          Authorization: auth,
        },
      },
      paymentEngineUrl: paymentEngine.url,
      cognitoUrl: paymentEngine.cognitoUrl,
    };

    return requestObject;
  };

  const generateAuthToken = async ({ paymentEngineCredentials }) => {
    try {
      const { cognitoUrl, requestConfig } = buildRequestObject({
        ...paymentEngineCredentials,
        contentType: 'application/x-www-form-urlencoded',
      });

      const url = `${cognitoUrl}/oauth2/token?grant_type=client_credentials`;
      const { data } = await axios.request({
        ...requestConfig,
        url,
        method: 'post',
      });

      const authorization = `${data.token_type} ${data.access_token}`;

      return { ...data, authorization };
    } catch (error) {
      if (error?.response) {
        throw buildCustomError({ step: PAYMENT_ENGINE.GENERATE_AUTH_TOKEN, error });
      }
      throw error;
    }
  };

  const createZeroAuth = async ({ payload, paymentEngineCredentials }) => {
    try {
      const { authorization } = await generateAuthToken({ paymentEngineCredentials });

      const { paymentEngineUrl, requestConfig } = buildRequestObject({
        ...paymentEngineCredentials,
        authorization,
      });

      const url = `${paymentEngineUrl}/zeroauth`;
      const { data } = await axios.request({
        ...requestConfig,
        url,
        method: 'post',
        data: payload,
      });

      return data;
    } catch (error) {
      throw new CustomError({
        message: replaceStep(errorMessage, PAYMENT_ENGINE.CREATE_ZERO_AUTH).replace('{msg}', 'Credit Card Invalid'),
        statusCode: STATUS_CODE.PAYMENT_REQUIRED,
      });
    }
  };

  return {
    createZeroAuth,
  };
};

module.exports = paymentEngineService;
