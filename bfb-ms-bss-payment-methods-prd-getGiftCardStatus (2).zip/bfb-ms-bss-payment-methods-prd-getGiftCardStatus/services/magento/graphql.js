const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const magentoGraphQLService = ({
  config,
  axios,
  CustomError,
  secretManager,
  enums: {
    PAYMENT_ENGINE_CHECKOUT: {
      STORE,
    },
  },
}) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const getProductBySKU = async ({ sku, countryCode }) => {
    try {
      await config.loadPaymentEngineCheckoutConfiguration(config, secretManager);

      const store = config.paymentEngineCheckout.secretsManagerCheckoutConfig[`${countryCode}_${STORE}`];

      const instance = axios.create({
        baseURL: config.magentoGQL.endpoint,
        headers: {
          'content-type': 'application/json',
          store,
        },
        responseType: 'application/json',
      });

      const body = JSON.stringify({
        query: `{
        products(
          filter: {
              sku: { eq: "${sku}"},
          }
          sort: { sort_order: DESC }
          pageSize: 30
          currentPage: 1
        ) {
          items {
            name
            sku
            customAttributes(
              fields: [
                "expiration_timestamp"
              ]
            )
            price_range {
              minimum_price {
                final_price {
                  currency
                  value
                }
              }
            }
          }
        }
      }`,
        variables: {},
      });

      const { data } = await instance.post('graphql', body);
      return data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  const getProductBySKUWithCache = async ({ sku, countryCode }) => {
    try {
      await config.loadPaymentEngineCheckoutConfiguration(config, secretManager);

      const store = config.paymentEngineCheckout.secretsManagerCheckoutConfig[`${countryCode}_${STORE}`];

      const query = `query {
        products(
          filter: {
            sku: { eq: "${sku}"},
          }
          sort: { sort_order: DESC }
          pageSize: 30
          currentPage: 1
        ) {
          items {
            name
            sku
            customAttributes(
              fields: [
                "event_expiration_date",
                "entitlement_expiration_date"
              ]
            ),
            price_range {
              minimum_price {
                final_price {
                  currency
                  value
                }
              }
            }
          }
        }
      }`;

      const encodedQuery = encodeURIComponent(query);

      const instance = axios.create({
        baseURL: `${config.magentoGQL.endpoint}?query=${encodedQuery}`,
        headers: {
          'content-type': 'application/json',
          store,
        },
        responseType: 'application/json',
      });

      const { data } = await instance.get();

      return data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    getProductBySKU,
    getProductBySKUWithCache,
  };
};

module.exports = magentoGraphQLService;
