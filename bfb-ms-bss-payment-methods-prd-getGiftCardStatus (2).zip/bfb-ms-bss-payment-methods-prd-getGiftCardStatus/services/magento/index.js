const magentoService = ({
  axios,
  CustomError,
  errorMessageHandler,
  getHttpStatusCode,
  config: { magento },
}) => {
  const errorMessage = 'Error in magento service: {msg}';

  const { endpoint, authToken, timeout } = magento;

  const invalidatePaymentSession = async customer_vrio_id => {
    try {
      const requestConfig = {
        headers: {
          Authorization: `Bearer ${authToken}`,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
      };

      const url = `${endpoint}/rest/V1/paymentsession/invalidate`;
      const response = await axios.request({
        ...requestConfig,
        url,
        method: 'post',
        data: { vrio_id: customer_vrio_id },
      });

      return response.data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  const updateOrderStatus = async ({
    store, entity_id, state, status,
  }) => {
    try {
      const requestConfig = {
        headers: {
          Authorization: `Bearer ${authToken}`,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
      };

      const url = new URL(`${endpoint}/rest/${store}/V1/orders`);

      const body = {
        entity: {
          entity_id,
          state,
          status,
        },
      };

      const response = await axios.request({
        ...requestConfig,
        url: url.href,
        method: 'post',
        data: body,
      });

      return response.data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    invalidatePaymentSession,
    updateOrderStatus,
  };
};

module.exports = magentoService;
