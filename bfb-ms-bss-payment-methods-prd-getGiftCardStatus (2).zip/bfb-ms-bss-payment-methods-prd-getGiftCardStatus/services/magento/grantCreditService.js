const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const magentoGrantCreditService = ({ config, axios, CustomError }) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';
  const { endpoint, token, timeout } = config.magento;

  const auth = `Bearer ${Buffer.from(`${token}`).toString()}`;

  const grantCredit = async (body, store) => {

    try {
      const instance = axios.create({
        baseURL: endpoint,
        headers: {
          Authorization: auth,
          'cache-control': 'no-cache',
          'content-type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const { data } = await instance.put(`rest/${store}/V1/CustomerStoreCredit/setStoreCredit`, body);

      return data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    grantCredit,
  };
};

module.exports = magentoGrantCreditService;
