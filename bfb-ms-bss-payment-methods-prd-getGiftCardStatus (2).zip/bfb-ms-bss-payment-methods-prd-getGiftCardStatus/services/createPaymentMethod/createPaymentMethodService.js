const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const createPaymentMethodService = ({
  axios,
  CustomError,
}) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const createPaymentMethod = async (body, config) => {
    const {
      token,
      url,
      timeout,
    } = config;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          Authorization: `Basic ${token}`,
          'cache-control': 'no-cache',
          'content-type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const response = await instance.post('/payment_methods', body);
      return response.data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    createPaymentMethod,
  };
};

module.exports = createPaymentMethodService;
