const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const attValidateTelephoneService = ({
  axios,
  CustomError,
}) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const attValidateTelephone = async (telephoneNumber, attmx) => {
    const {
      url,
      xapikey,
      timeout,
    } = attmx;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          'x-api-key': xapikey,
          'cache-control': 'no-cache',
          'content-type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const response = await instance.get(`/intgw/v1/basic-user-info?mdn=${telephoneNumber}`);
      return response.data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    attValidateTelephone,
  };
};

module.exports = attValidateTelephoneService;
