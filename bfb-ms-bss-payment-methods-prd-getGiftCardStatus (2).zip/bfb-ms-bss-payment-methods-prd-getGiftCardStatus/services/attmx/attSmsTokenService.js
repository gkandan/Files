const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const attSmsTokenService = ({
  axios,
  CustomError,
}) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const attSmsToken = async (body, attmx) => {
    const {
      url,
      xapikey,
      timeout,
    } = attmx;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          'x-api-key': xapikey,
          'cache-control': 'no-cache',
          'content-type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const response = await instance.post('/intgw/v1/sms-token', body);
      return response.data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    attSmsToken,
  };
};

module.exports = attSmsTokenService;
