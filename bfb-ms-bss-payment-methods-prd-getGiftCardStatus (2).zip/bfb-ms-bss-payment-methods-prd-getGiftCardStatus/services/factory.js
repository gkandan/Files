const createPaymentMethodService = require('./createPaymentMethod/createPaymentMethodService');
const updatePaymentMethodService = require('./updatePaymentMethod/updatePaymentMethodService');
const getPaymentMethodService = require('./getPaymentMethodSubscription/getPaymentMethodService');
const attValidateTelephoneService = require('./attmx/attValidateTelephoneService');
const attSmsTokenService = require('./attmx/attSmsTokenService');
const attValidateTokenService = require('./attmx/attValidateTokenService');
const attCheckExternalIdService = require('./lavindicia/attCheckExternalIdService');
const attPaymentMethodsService = require('./lavindicia/attPaymentMethodsService');
const attPaymentExecuteService = require('./attmx/attPaymentExecuteService');
const consultPaymentMethodsBRService = require('./consultPaymentMethods/consultPaymentMethodsBRService');
const giftCardAuthService = require('./incomm/authService');
const giftCardStatusService = require('./incomm/giftCardStatusService');
const giftCardRedeemService = require('./incomm/giftCardRedeemService');
const giftCardCancelService = require('./incomm/giftCardCancelService');
const giftCardStatusDGoRecorder = require('./dGo/giftCardStatusDGoRecorder');
const giftCardStatusDGoValidator = require('./dGo/giftCardStatusDGoValidator');
const vindiciaGrantCreditService = require('./vindicia/grantCreditService');
const vindiciaGetAccountService = require('./vindicia/getAccountService');
const magentoGrantCreditService = require('./magento/grantCreditService');
const updateAccountService = require('./vindicia/updateAccountService');
const killBillService = require('./killbill');
const paymentEngineService = require('./paymentEngine');
const paymentEngineCheckoutService = require('./paymentEngineCheckout');
const magentoService = require('./magento');
const magentoGraphQLService = require('./magento/graphql');
const pnlService = require('./pnl');

module.exports = dependencies => ({
  createPaymentMethodService: createPaymentMethodService(dependencies),
  updatePaymentMethodService: updatePaymentMethodService(dependencies),
  getPaymentMethodService: getPaymentMethodService(dependencies),
  attValidateTelephoneService: attValidateTelephoneService(dependencies),
  attSmsTokenService: attSmsTokenService(dependencies),
  attValidateTokenService: attValidateTokenService(dependencies),
  attCheckExternalIdService: attCheckExternalIdService(dependencies),
  attPaymentMethodsService: attPaymentMethodsService(dependencies),
  attPaymentExecuteService: attPaymentExecuteService(dependencies),
  consultPaymentMethodsBRService: consultPaymentMethodsBRService(dependencies),
  giftCardAuthService: giftCardAuthService(dependencies),
  giftCardStatusService: giftCardStatusService(dependencies),
  giftCardRedeemService: giftCardRedeemService(dependencies),
  giftCardCancelService: giftCardCancelService(dependencies),
  giftCardStatusDGoRecorder: giftCardStatusDGoRecorder(dependencies),
  giftCardStatusDGoValidator: giftCardStatusDGoValidator(dependencies),
  vindiciaGrantCreditService: vindiciaGrantCreditService(dependencies),
  vindiciaGetAccountService: vindiciaGetAccountService(dependencies),
  magentoGrantCreditService: magentoGrantCreditService(dependencies),
  updateAccountService: updateAccountService(dependencies),
  killBillService: killBillService(dependencies),
  paymentEngineService: paymentEngineService(dependencies),
  paymentEngineCheckoutService: paymentEngineCheckoutService(dependencies),
  magentoService: magentoService(dependencies),
  magentoGraphQLService: magentoGraphQLService(dependencies),
  pnlService: pnlService(dependencies),
});
