let cachedAuthToken;

const paymentEngineCheckoutService = ({
  axios,
  CustomError,
  errorMessageHandler,
  getHttpStatusCode,
  config,
  enums: {
    STEPS: {
      PAYMENT_ENGINE,
    },
    PAYMENT_ENGINE_CHECKOUT: {
      CHECKOUT_API_KEY,
      COGNITO_CHECKOUT_AUTH_BASIC,
    },
  },
  jwtDecode: {
    decryptToken,
  },
  secretManager,
}) => {
  const errorMessage = 'Error in Payment Engine Checkout service {step} step: {msg}';

  const isExpiredToken = token => {
    const decodedToken  = decryptToken(token);

    if (!decodedToken || !decodedToken.exp) {
      return true;
    }

    const currentDate = Math.floor(Date.now() / 1000);

    return currentDate >= decodedToken.exp;
  };

  const replaceStep = (string, step) => string.replace('{step}', step);

  const buildCustomError = ({ step, error }) => new CustomError({
    message: errorMessageHandler(replaceStep(errorMessage, step), error),
    additionalData: {
      ...error.additionalData,
      step,
      error: error.response?.data,
    },
    statusCode: getHttpStatusCode(error),
  });

  const generateAuthToken = async countryCode => {
    try {
      const authBasic = config.paymentEngineCheckout.secretsManagerCheckoutConfig[`${countryCode}_${COGNITO_CHECKOUT_AUTH_BASIC}`];

      const instance = axios.create({
        baseURL: config.paymentEngineCheckout.cognitoUrl,
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Basic ${authBasic}`,
        },
      });

      const {
        data: {
          access_token: accessToken,
        },
      } = await instance.post('/oauth2/token?grant_type=client_credentials');

      return accessToken;
    } catch (error) {
      if (error?.response) {
        throw buildCustomError({ step: PAYMENT_ENGINE.GENERATE_AUTH_TOKEN, error });
      }
      throw error;
    }
  };

  const getAuthToken = async countryCode => {
    if (config.paymentEngineCheckout.isCheckoutCallCacheEnabled) {
      if (!cachedAuthToken || isExpiredToken(cachedAuthToken)) {
        cachedAuthToken = await generateAuthToken(countryCode);
      }

      return cachedAuthToken;
    }

    const token = await generateAuthToken(countryCode);

    return token;
  };

  const checkout = async ({ payload, countryCode }) => {
    try {
      await config.loadPaymentEngineCheckoutConfiguration(config, secretManager);

      const apiKey = config.paymentEngineCheckout.secretsManagerCheckoutConfig[`${countryCode}_${CHECKOUT_API_KEY}`];

      const token = await getAuthToken(countryCode);

      const instance = axios.create({
        baseURL: config.paymentEngineCheckout.url,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'x-api-key': apiKey,
        },
      });

      const { data } = await instance.post('/request', payload);

      return data;
    } catch (error) {
      if (error?.response) {
        throw buildCustomError({ step: PAYMENT_ENGINE.CHECKOUT, error });
      }
      throw error;
    }
  };

  return {
    checkout,
  };
};

module.exports = paymentEngineCheckoutService;
