const { getHttpStatusCode, errorMessageHandler, handleForbiddenError } = require('../../commons/utils/utility');

const authService = ({ axios, CustomError }) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const auth = async (incommConfigs, dbConfigs, repository, db) => {
    try {
      let response;
      await db.connect(dbConfigs.uri, dbConfigs.dbName);
      const data = await repository.bearer.findOne({}, { _id: true });
      let expireIn;
      let recreate = false;

      if (data && data.updated) {
        expireIn = new Date(new Date(data.updated).getTime() + ((data.expires_in - 600) * 1000)).getTime();
        if (new Date().getTime() >= expireIn) recreate = true;
      }

      if (!data || recreate) {
        const {
          clientId,
          clientSecret,
          scope,
          grantType,
        } = incommConfigs.auth;

        const instance = axios.create({
          baseURL: incommConfigs.URL,
          headers: {
            'Content-Type': 'application/x-www-formurlencoded',
          },
          timeout: parseInt(incommConfigs.configs.timeout),
          responseType: 'application/json',
        });

        const resp = await instance.post('security/rtg-security/v2/token', null, {
          params: {
            client_id: clientId,
            client_secret: clientSecret,
            scope,
            grant_type: grantType,
          },
        });

        if (!data) {
          await repository.bearer.insert({ ...resp.data, created: new Date(), updated: new Date() });
        } else {
          await repository.bearer.updateAndFind({ _id: resp.data._id }, { ...resp.data, updated: new Date() });
        }

        response = resp.data.access_token;

      } else {
        response = data.access_token;
      }


      return response;
    } catch (error) {
      const statusCode = handleForbiddenError(getHttpStatusCode(error));

      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode,
      });
    }
  };

  return {
    auth,
  };
};

module.exports = authService;
