const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const giftCardStatusService = ({ axios, CustomError }) => {
  const errorMessage = 'Error on bfb-ms-bss-payment-methods-package: {msg}';

  const validateGiftCard = async (body, incommConfigs, responseCodes) => {
    try {
      const {
        giftCardNumber,
        transactionId,
        source,
        auth,
      } = body;

      const reqPayload = {
        RetailTransactionTVRequest: {
          dateTime: new Date(),
          product: {
            partnerName: incommConfigs.configs.partnerName,
            inventoryID: giftCardNumber,
            productCat: incommConfigs.configs.productCat,
          },
          source: source,
          transactionID: transactionId,
        },
      };

      const Authorization = `Bearer ${auth}`;

      const instance = axios.create({
        baseURL: incommConfigs.URL,
        headers: {
          Authorization,
          Accept: 'application/json',
          'Content-Type': 'application/json; charset=UTF-8',
        },
        timeout: parseInt(incommConfigs.configs.timeout),
        responseType: 'application/json',
      });

      const { data } = await instance.post('ws/rtg-tv/v2/api/getStatus', reqPayload);
      if (responseCodes[data.RetailTransactionTVResponse.responseCode]) {
        const error = {
          response: {
            data: {
              message: responseCodes.default,
              stack: responseCodes[data.RetailTransactionTVResponse.responseCode].Description,
              statusCode: responseCodes[data.RetailTransactionTVResponse.responseCode].statusCode,
            },
            status: responseCodes[data.RetailTransactionTVResponse.responseCode].statusCode,
          },
        };
        throw error;
      }

      return data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    validateGiftCard,
  };
};

module.exports = giftCardStatusService;
