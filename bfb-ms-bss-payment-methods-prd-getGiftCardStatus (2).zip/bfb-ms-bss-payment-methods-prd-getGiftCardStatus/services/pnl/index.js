

const pnlService = ({
  axios,
  CustomError,
  StatusCode,
  config: { pnl },
  enums,
}) => {
  const isBR = country => country === enums.COUNTRY_CODES.BR;

  const addMercadoPagoEntitlement = async ({
    country,
    vrioCustomerId,
    preferenceId,
    sku,
  }) => {
    try {
      const pnlConfig = isBR(country) ? pnl.br : pnl.ssla;
      const instance = axios.create({
        baseURL: `${pnlConfig.url}/pnl`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const { data } = await instance.post('/entitlements', {
        vrioCustomerId,
        preferenceId,
        sku,
        vendor: enums.VENDOR_NAMES.MERCADO_PAGO,
        actionType: 'add',
      }, {
        params: {
          country,
        },
      });

      return data;
    } catch (error) {
      throw new CustomError({
        message: error.message,
        statusCode: error.statusCode || StatusCode.InternalServerError,
      });
    }
  };

  const removeMercadoPagoEntitlement = async ({
    country,
    vrioCustomerId,
    preferenceId,
    sku,
  }) => {
    try {
      const pnlConfig = isBR(country) ? pnl.br : pnl.ssla;
      const instance = axios.create({
        baseURL: `${pnlConfig.url}/pnl`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const { data } = await instance.post('/entitlements', {
        vrioCustomerId,
        preferenceId,
        sku,
        vendor: enums.VENDOR_NAMES.MERCADO_PAGO,
        actionType: 'remove',
      }, {
        params: {
          country,
        },
      });

      return data;
    } catch (error) {
      throw new CustomError({
        message: error.message,
        statusCode: error.statusCode || StatusCode.InternalServerError,
      });
    }
  };

  return {
    addMercadoPagoEntitlement,
    removeMercadoPagoEntitlement,
  };
};

module.exports = pnlService;
