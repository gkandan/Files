const { getHttpStatusCode, errorMessageHandler } = require('../../commons/utils/utility');

const getPaymentMethodSubscriptionService = ({
  axios,
  CustomError,
}) => {
  const errorMessage = 'Error on get payment-method: {msg}';

  const getPaymentMethodSubscription = async (accountId, config) => {
    const {
      token,
      url,
      timeout,
    } = config;

    try {
      const instance = axios.create({
        baseURL: url,
        headers: {
          Authorization: `Basic ${token}`,
          'cache-control': 'no-cache',
          'Content-Type': 'application/json',
        },
        timeout: parseInt(timeout, 10),
        responseType: 'application/json',
      });

      const response = await instance.get(`/subscriptions?account=${accountId}`);
      return response.data;
    } catch (error) {
      throw new CustomError({
        message: errorMessageHandler(errorMessage, error),
        error,
        statusCode: getHttpStatusCode(error),
      });
    }
  };

  return {
    getPaymentMethodSubscription,
  };
};

module.exports = getPaymentMethodSubscriptionService;
