require('dotenv').config();

module.exports = {
  applicationName: process.env.SERVICE,
  application: process.env.SERVICE,
  environment: process.env.STAGE,
  region: process.env.REGION,
  logger: {
    name: process.env.SERVICE,
  },
  logs: {
    application: process.env.APPLICATION_LOG,
    environment: process.env.ENVIRONMENT_LOG,
  },

  vindicia: {
    BR: {
      url: process.env.VINDICIA_ENDPOINT,
      token: process.env.BR_VINDICIA_TOKEN,
      timeout: process.env.VINDICIA_TIMEOUT,
    },
    LA: {
      url: process.env.VINDICIA_ENDPOINT,
      token: process.env.LA_VINDICIA_TOKEN,
      timeout: process.env.VINDICIA_TIMEOUT,
    },
    config: {
      reasonToCredit: 'Gift Card Redemption',
    },
  },

  attmx: {
    url: process.env.ATTMX_ENDPOINT,
    xapikey: process.env.ATTMX_X_API_KEY,
    timeout: process.env.ATTMX_TIMEOUT,
  },

  magento: {
    endpoint: process.env.BR_MAGENTO_ENDPOINT,
    token: process.env.BR_MAGENTO_TOKEN,
    timeout: process.env.MAGENTO_TIMEOUT,
    authToken: process.env.MAGENTO_AUTH_TOKEN,
  },
  magentoGQL: {
    endpoint: process.env.MAGENTO_GRAPHQL_URL,
  },
  verifyRegex: /^([a-zA-Z0-9]{8})-([a-zA-Z0-9]{4})-([a-zA-Z0-9]{4})-([a-zA-Z0-9]{4})-([a-zA-Z0-9]{12})$/,

  mongodb: {
    uri: process.env.MONGO_URI,
    dbName: 'giftCard',
    collections: {
      gift: 'giftCard',
      bearer: 'bearer',
    },
    maxPoolSize: parseInt(process.env.MONGO_MAX_POOL_SIZE || 10000, 10),
    minPoolSize: parseInt(process.env.MONGO_MIN_POOL_SIZE || 500, 10),
  },
  dynamoDb: {
    mercadoPago: {
      tableName: process.env.DYNAMO_MERCADOPAGO_TABLE_NAME,
    },
    ppvEntitlementDeletionTable: process.env.DYNAMO_ENTITLEMENT_DELETION_TABLE,
  },
  sqs: {
    entitlementsToRemoveQueue: process.env.REMOVE_ENTITLEMENTS_QUEUE,
  },
  getKillBillConfiguration: async (self, secretManager) => {
    if (!self.killbill.credentials) {
      self.killbill.credentials = await secretManager.getSecretValue(process.env.KILLBILL_SECRET_MANAGER);
    }
  },
  getPaymentEngineConfiguration: async (self, secretManager) => {
    if (!self.paymentEngine.credentials) {
      self.paymentEngine.credentials = await secretManager.getSecretValue(process.env.PAYMENT_ENGINE_SECRET_MANAGER);
    }
  },
  loadPaymentEngineCheckoutConfiguration: async (self, secretManager) => {
    if (!self.paymentEngineCheckout.secretsManagerCheckoutConfig) {
      self.paymentEngineCheckout.secretsManagerCheckoutConfig = await secretManager.getSecretValue(
        process.env.PAYMENT_ENGINE_CHECKOUT_SECRET_MANAGER,
      );
    }
  },
  paymentEngine: {
    url: process.env.PAYMENT_ENGINE_ENDPOINT,
    secretName: process.env.PAYMENT_ENGINE_SECRET_MANAGER,
    cognitoUrl: process.env.PAYMENT_ENGINE_COGNITO_URL,
  },
  paymentEngineCheckout: {
    url: process.env.PAYMENT_ENGINE_CHECKOUT_ENDPOINT,
    cognitoUrl: process.env.PAYMENT_ENGINE_CHECKOUT_COGNITO_URL,
    allowedCountries: process.env.PAYMENT_ENGINE_CHECKOUT_ALLOWED_COUNTRIES?.split(',') || [],
    allowedBusinessUnit: process.env.PE_ALLOWED_BUSINESS_UNIT?.split(',') || [],
    sumMinutesToExpiration: +process.env.PAYMENT_ENGINE_CHECKOUT_SUM_MINUTES_TO_EXPIRE,
    isCheckoutCallCacheEnabled: process.env.PE_CHECKOUT_CACHE_ENABLED === 'true',
    customActionNameEnabled: process.env.CUSTOM_ACTION_NAME_ENABLED === 'true',
  },
  killbill: {
    endpoint: process.env.KILLBILL_ENDPOINT,
    callbackEndpoint: process.env.KILLBILL_CALLBACK_ENDPOINT,
    secretName: process.env.KILLBILL_SECRET_MANAGER,
    usingExternalId: process.env.KILLBILL_PRE_REQUEST_USING_EXTERNAL_KEY === 'true',
  },
  incomm: {
    configs: {
      partnerName: 'DirecTV Go',
      timeout: 7000,
      productCat: 'PIN',
    },
    auth: {
      clientId: process.env.GIFT_CARD_USERNAME,
      clientSecret: process.env.GIFT_CARD_PASSWORD,
      scope: 'read',
      grantType: 'client_credentials',
    },
    URL: process.env.GIFT_CARD_PARTNER,
  },
  pnl: {
    br: {
      url: process.env.PNL_BR_ENDPOINT,
    },
    ssla: {
      url: process.env.PNL_SSLA_ENDPOINT,
    },
  },
};
