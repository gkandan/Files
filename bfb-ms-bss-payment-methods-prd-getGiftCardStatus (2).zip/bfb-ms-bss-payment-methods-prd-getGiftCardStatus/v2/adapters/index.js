const crypto = require('crypto');

const updatePaymentMethodWrapper = require('./updatePaymentMethod');
const getPaymentMethodWrapper = require('./getPaymentMethod');
const consultPaymentMethodsWrapper = require('./consultPaymentMethods');
const giftCardRedeemMethodWrapper = require('./giftCardRedeemMethod');
const getAccountCreditWrapper = require('./getAccountCredit');

module.exports = dependencies => ({
  updatePaymentMethod: updatePaymentMethodWrapper({
    schemas: dependencies.schemas,
    services: dependencies.services,
    helpers: dependencies.helpers,
    config: dependencies.config,
    commons: dependencies.commons,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
    secretManager: dependencies.secretManager,
    dd: dependencies.dd,
  }).updatePaymentMethod,
  consultPaymentMethods: consultPaymentMethodsWrapper({
    schemas: dependencies.schemas,
    services: dependencies.services,
    helpers: dependencies.helpers,
    config: dependencies.config,
    commons: dependencies.commons,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
    secretManager: dependencies.secretManager,
    dd: dependencies.dd,
  }).consultPaymentMethods,
  getPaymentMethod: getPaymentMethodWrapper({
    schemas: dependencies.schemas,
    services: dependencies.services,
    helpers: dependencies.helpers,
    config: dependencies.config,
    commons: dependencies.commons,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
    secretManager: dependencies.secretManager,
    getPaymentMethodService: dependencies.services.getPaymentMethodService,
    dd: dependencies.dd,
  }).getPaymentMethod,
  giftCardRedeem: giftCardRedeemMethodWrapper({
    schemas: dependencies.schemas,
    services: dependencies.services,
    helpers: dependencies.helpers,
    config: dependencies.config,
    commons: dependencies.commons,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
    secretManager: dependencies.secretManager,
    giftCardRedeemService: dependencies.services.giftCardRedeemService,
    crypto,
    repository: dependencies.repositoryMongoDb,
    db: dependencies.mongo,
    responseCodes: dependencies.responseCodes,
    dd: dependencies.dd,
  }).redeem,
  getAccountCredit: getAccountCreditWrapper({
    vindiciaGetAccountService: dependencies.services.vindiciaGetAccountService,
    services: dependencies.services,
    config: dependencies.config,
    commons: dependencies.commons,
    helpers: dependencies.helpers,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
    secretManager: dependencies.secretManager,
    dd: dependencies.dd,
  }).getAccountCredit,
});
