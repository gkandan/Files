const getPaymentMethodWrapper = ({
  helpers,
  config,
  commons: { enums },
  CustomError,
  StatusCode,
  services,
  secretManager,
  dd,
}) => {
  const getPropValue = (props, key) => props.find(prop => prop.key === key)?.value;
  const getPaymentMethod = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const { Authorization } = payload.headers;

      const { decodedToken } = await helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      dd.setDdTag('customerId', decodedToken?.customerId);
      dd.setDdTag('country', decodedToken?.iso2Code);
      dd.setDdTag('vrioId', decodedToken?.vrioCustomerId);
      dd.setDdTag('businessUnit', decodedToken?.businessUnit);
      dd.setDdTag('email', decodedToken?.email);

      const killBillCredentials = await helpers.getKillBillConfigByCountry({ config, secretManager, decodedToken });

      const account = await services.killBillService.getAccountByExternalId(decodedToken.customerId, killBillCredentials);
      const paymentMethods = await services.killBillService.getPaymentMethods(account.accountId, killBillCredentials);
      const primaryPaymentMethod = paymentMethods.find(paymentMethod => paymentMethod.isDefault === true);

      if (!primaryPaymentMethod || !primaryPaymentMethod.pluginInfo) {
        return onError({
          message: enums.RESPONSE_MESSAGES.WITHOUT_PRIMARY_CREDIT_CARD,
          statusCode: 404,
        });
      }

      return onSuccess({
        last4digits: getPropValue(primaryPaymentMethod.pluginInfo.properties, 'card_mask')?.slice(-4),
        bin: getPropValue(primaryPaymentMethod.pluginInfo.properties, 'card_mask')?.slice(0, 6),
        cardType: getPropValue(primaryPaymentMethod.pluginInfo.properties, 'card_flag'),
        paymentType: getPropValue(primaryPaymentMethod.pluginInfo.properties, 'payment_type'),
      });

    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    getPaymentMethod,
  };
};

module.exports = getPaymentMethodWrapper;
