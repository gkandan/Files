const getAccountCreditWrapper = ({
  vindiciaGetAccountService,
  helpers,
  services,
  config,
  commons: { enums },
  CustomError,
  StatusCode,
  secretManager,
  dd,
}) => {
  const isKillBill = billing => billing === enums.BILLING_SYSTEMS.KILLBILL;
  const getAccountCredit = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const { Authorization } = payload.headers;

      const { decodedToken, configCountry } = await helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      dd.setDdTag('customerId', decodedToken?.customerId);
      dd.setDdTag('country', decodedToken?.iso2Code);
      dd.setDdTag('vrioId', decodedToken?.vrioCustomerId);
      dd.setDdTag('businessUnit', decodedToken?.businessUnit);
      dd.setDdTag('email', decodedToken?.email);

      const billingSystem = decodedToken.billing || decodedToken.msoProvider || enums.BILLING_SYSTEMS.VINDICIA;


      if (isKillBill(billingSystem)) {
        const killBillCredentials = await helpers.getKillBillConfigByCountry({ config, secretManager, decodedToken });
        const account = await services.killBillService.getAccountCredit(decodedToken.customerId, killBillCredentials);

        const result = [];

        if (account && account.accountBalance) {
          result.push({
            amount: account.accountBalance >= 0 ? 0 : account.accountBalance * -1,
          });
        }

        return onSuccess(result);
      }

      const account = await vindiciaGetAccountService
        .getAccount(decodedToken.customerId, configCountry);

      let result = [];

      if (account && account.credit && account.credit.currency_amounts && account.credit.currency_amounts.data) {
        result = account.credit.currency_amounts.data;
      }

      return onSuccess(result);
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    getAccountCredit,
  };
};

module.exports = getAccountCreditWrapper;
