const updatePaymentMethodWrapper = ({
  services: {
    updatePaymentMethodService,
    updateAccountService,
    killBillService,
    magentoService,
  },
  schemas: {
    updatePaymentMethodSchemas: {
      updatePaymentMethodSchemaVindicia,
      updatePaymentMethodSchemaKillbill,
    },
  },
  config,
  helpers,
  commons: { enums },
  CustomError,
  StatusCode,
  secretManager,
  dd,
}) => {

  const isKillBill = billing => billing === enums.BILLING_SYSTEMS.KILLBILL;

  const shouldUpdateFederalTaxId = (federalTaxId, countryCode) => federalTaxId && [enums.COUNTRY_CODES.BR].includes(countryCode);

  const updatePaymentMethodVindicia = async ({ decodedToken, configCountry, requestBody }) => {

    const { error } = updatePaymentMethodSchemaVindicia.validate(requestBody);
    if (error) {
      throw new CustomError({ message: enums.RESPONSE_MESSAGES.INVALID_PARAMETER, statusCode: 404 });
    }

    const {
      federalTaxId,
      payment_methods: { data: [{ vid, id }] },
    } = requestBody;

    const { customerId, iso2Code: countryCode } = decodedToken;

    if (shouldUpdateFederalTaxId(federalTaxId, countryCode)) {
      const metadata = {
        [enums.VINDICIA_CUSTOM_TAGS[countryCode].FEDERAL_TAX_ID]: federalTaxId,
      };
      await updateAccountService.updateCustomFields(customerId, metadata, configCountry);
    }

    const data = {
      id: customerId,
      payment_methods: {
        data: [
          {
            object: enums.RESPONSE_MESSAGES.TYPE_OBJECT,
            vid,
            id,
            type: enums.RESPONSE_MESSAGES.PAYMENT_METHOD_CREDIT_CARD_TYPE,
          },
        ],
      },
    };

    const updatePaymentMethodInAccount = await updatePaymentMethodService
      .updatePaymentMethod(customerId, data, configCountry);

    updatePaymentMethodInAccount.object = enums.RESPONSE_MESSAGES.SUCCESSFULLY_CHANGED;
    return updatePaymentMethodInAccount;
  };

  const updatePaymentMethodKillbill = async ({ requestBody, decodedToken }) => {
    const { error } = updatePaymentMethodSchemaKillbill.validate(requestBody);

    if (error) {
      throw new CustomError({ message: enums.RESPONSE_MESSAGES.INVALID_PARAMETER, statusCode: 400 });
    }

    const killBillCredentials = await helpers.getKillBillConfigByCountry({ config, secretManager, decodedToken });

    const paymentMethod = requestBody.payment_methods.data[0];

    const data = {
      pluginName: 'payment-engine-plugin',
      pluginInfo: {
        properties: Object.entries(paymentMethod).map(cardInfo => {
          const [key, value] = cardInfo;
          return {
            key,
            value,
            isUpdatable: false,
          };
        }),
      },
    };
    data.pluginInfo.properties.push({ key: 'payment_type', value: 'credit_card', isUpdatable: false });

    await config.getPaymentEngineConfiguration(config, secretManager);

    const account = await killBillService.getAccountByExternalId(decodedToken.vrioCustomerId, killBillCredentials);

    /* eslint no-empty: ["error", { "allowEmptyCatch": true }] */
    try {
      await magentoService.invalidatePaymentSession(decodedToken.vrioCustomerId);
    } catch { }

    await killBillService.addAPaymentMethod(account.accountId, data, killBillCredentials);

    return data;
  };

  const updatePaymentMethod = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const { Authorization } = payload.headers;

      const { decodedToken, configCountry } = helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      dd.setDdTag('customerId', decodedToken?.customerId);
      dd.setDdTag('country', decodedToken?.iso2Code);
      dd.setDdTag('vrioId', decodedToken?.vrioCustomerId);
      dd.setDdTag('businessUnit', decodedToken?.businessUnit);
      dd.setDdTag('email', decodedToken?.email);

      const billingSystem = decodedToken.billing || decodedToken.msoProvider || enums.BILLING_SYSTEMS.VINDICIA;

      const requestBody = JSON.parse(payload.body);

      if (isKillBill(billingSystem)) {
        const updateKillbill = await updatePaymentMethodKillbill({ requestBody, decodedToken });
        return onSuccess(updateKillbill);
      }

      const updateVindicia = await updatePaymentMethodVindicia({ decodedToken, configCountry, requestBody });
      return onSuccess(updateVindicia);

    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    updatePaymentMethod,
    updatePaymentMethodVindicia,
  };
};

module.exports = updatePaymentMethodWrapper;
