const giftCardRedeemWrapper = ({
  schemas: {
    giftCardRedeemValidationSchema: {
      giftCardRedeemValidationSchemaJoi,
    },
  },
  services: {
    vindiciaGrantCreditService,
    giftCardRedeemService,
    giftCardCancelService,
    giftCardAuthService,
    giftCardStatusDGoRecorder,
    killBillService,
  },
  responseCodes,
  config,
  repository,
  db,
  crypto,
  commons: { enums },
  helpers,
  CustomError,
  StatusCode,
  secretManager,
  dd,
}) => {
  const redeem = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    const grantCreditPayload = JSON.parse(payload.body);

    try {
      const { headers: { Authorization } } = payload;

      const { decodedToken, configCountry } = await helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      const { error } = await giftCardRedeemValidationSchemaJoi.validate(grantCreditPayload);

      dd.setDdTag('customerId', decodedToken?.customerId);
      dd.setDdTag('country', decodedToken?.iso2Code);
      dd.setDdTag('vrioId', decodedToken?.vrioCustomerId);
      dd.setDdTag('businessUnit', decodedToken?.businessUnit);
      dd.setDdTag('email', decodedToken?.email);

      if (error) {
        error.statusCode = enums.RESPONSE_MESSAGES.STATUS_CODE_400;
        throw error;
      }

      grantCreditPayload.vindiciaId = decodedToken.customerId;
      grantCreditPayload.transactionId = crypto.randomUUID();

      await giftCardStatusDGoRecorder
        .recorderGiftCard(
          grantCreditPayload,
          config.mongodb,
          repository,
          db,
        );

      grantCreditPayload.auth = await giftCardAuthService.auth(config.incomm, config.mongodb, repository, db);
      const redeemed = await giftCardRedeemService.redeemGiftCard(grantCreditPayload, config.incomm, responseCodes);

      await giftCardStatusDGoRecorder
        .recorderGiftCard(
          grantCreditPayload,
          config.mongodb,
          repository,
          db,
          redeemed,
        );

      const isKillBill = billing => billing === enums.BILLING_SYSTEMS.KILLBILL;

      const billingSystem = decodedToken.billing || decodedToken.msoProvider || enums.BILLING_SYSTEMS.VINDICIA;

      if (isKillBill(billingSystem)) {
        const killBillCredentials = await helpers.getKillBillConfigByCountry({ config, secretManager, decodedToken });
        const account = await killBillService.getAccountByExternalId(decodedToken.customerId, killBillCredentials);

        const result = await killBillService.createCredit({
          creditsArray: [
            {
              accountId: account.accountId,
              description: `${enums.KILLBILL_MESSAGES.GIFT_CARD_CODE}${grantCreditPayload.giftCardNumber}`,
              amount: redeemed.RetailTransactionTVResponse.productResp.inventoryRespInfo.faceValue,
              currency: redeemed.RetailTransactionTVResponse.productResp.inventoryRespInfo.denom,
            },
          ],
          killBillCredentials,
        });

        return onSuccess(result);
      }

      const result = await vindiciaGrantCreditService.postGrantCredit(
        grantCreditPayload.vindiciaId,
        {
          object: enums.REQUEST_PARAMS.VINDICIA_OBJECT_CURRENCY_AMOUNT,
          currency: redeemed.RetailTransactionTVResponse.productResp.inventoryRespInfo.denom,
          amount: redeemed.RetailTransactionTVResponse.productResp.inventoryRespInfo.faceValue,
          description: grantCreditPayload.giftCardNumber,
          reason: config.vindicia.config.reasonToCredit,
        },
        configCountry,
      );

      return onSuccess(result);
    } catch (errorCatch) {

      if (grantCreditPayload.auth) {
        try {
          grantCreditPayload.responseText = errorCatch?.message;
          await giftCardStatusDGoRecorder
            .recorderGiftCard(
              grantCreditPayload,
              config.mongodb,
              repository,
              db,
            );

          await giftCardCancelService.cancelGiftCard(grantCreditPayload, config.incomm, responseCodes);
        } catch (error) {
          return onError(errorCatch);
        }
      }
      return onError(errorCatch);
    }
  };
  return {
    redeem,
  };
};

module.exports = giftCardRedeemWrapper;
