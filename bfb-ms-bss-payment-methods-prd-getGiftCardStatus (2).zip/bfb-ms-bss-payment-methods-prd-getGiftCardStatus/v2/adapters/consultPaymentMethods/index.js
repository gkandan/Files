const consultPaymentMethodsWrapper = ({
  helpers,
  config,
  commons: { enums },
  CustomError,
  StatusCode,
  services,
  secretManager,
  dd,
}) => {

  const getPropValue = (props, key) => props.find(prop => prop.key === key)?.value;

  const mapPaymentMethodsKillBill = paymentMethods => paymentMethods.map(paymentMethod => {
    const pluginInfo = paymentMethod.pluginInfo;

    if (!pluginInfo) {
      throw new CustomError({
        message: enums.RESPONSE_MESSAGES.WITHOUT_PLUGIN_INFO,
        statusCode: 404,
      });
    }

    return {
      id: paymentMethod.externalKey,
      billingAddress: {
        name: getPropValue(pluginInfo.properties, 'card_name'),
        line1: getPropValue(pluginInfo.properties, 'street'),
        line2: getPropValue(pluginInfo.properties, 'number'),
        city: getPropValue(pluginInfo.properties, 'city'),
        district: getPropValue(pluginInfo.properties, 'state'),
        postal_code: getPropValue(pluginInfo.properties, 'zip_code'),
        country: getPropValue(pluginInfo.properties, 'country'),
      },
    };
  });

  const isKillBill = billing => billing === enums.BILLING_SYSTEMS.KILLBILL;

  const getPaymentMethodsKillBill = async ({
    decodedToken,
  }) => {
    const killBillCredentials = await helpers.getKillBillConfigByCountry({ config, secretManager, decodedToken });

    const account = await services.killBillService.getAccountByExternalId(decodedToken.customerId, killBillCredentials);

    const paymentMethods = await services.killBillService.getPaymentMethods(account.accountId, killBillCredentials);
    return mapPaymentMethodsKillBill(paymentMethods.filter(paymentMethod => paymentMethod.isDefault === true));
  };

  const getPaymentMethodsVindicia = async ({
    decodedToken,
    configCountry,
  }) => {
    const getPaymentMethodByAccount = await services.consultPaymentMethodsBRService
      .getPaymentMethodInAccount(decodedToken.customerId, configCountry);

    const arrayOfPaymentMethods = getPaymentMethodByAccount.payment_methods?.data.reduce((arr, paymentMethod) => {
      if ((paymentMethod.active === true) && (paymentMethod.primary === true)) {
        arr.push({
          billingAddress: paymentMethod.billing_address,
          id: paymentMethod.vid,
        });
      }
      return arr;
    }, []);

    if (!arrayOfPaymentMethods || !arrayOfPaymentMethods.length) {
      throw new CustomError({
        message: enums.RESPONSE_MESSAGES.WITHOUT_PRIMARY_CREDIT_CARD,
        statusCode: 404,
      });
    }

    return arrayOfPaymentMethods;
  };
  const consultPaymentMethods = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {

      const { Authorization } = payload.headers;

      const { decodedToken, configCountry } = await helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      dd.setDdTag('customerId', decodedToken?.customerId);
      dd.setDdTag('country', decodedToken?.iso2Code);
      dd.setDdTag('vrioId', decodedToken?.vrioCustomerId);
      dd.setDdTag('businessUnit', decodedToken?.businessUnit);
      dd.setDdTag('email', decodedToken?.email);

      const billingSystem = decodedToken.billing || decodedToken.msoProvider || enums.BILLING_SYSTEMS.VINDICIA;

      if (isKillBill(billingSystem)) {
        const paymentMethodsKillbill = await getPaymentMethodsKillBill({ decodedToken });

        if (!paymentMethodsKillbill.length) {
          throw new CustomError({
            message: enums.RESPONSE_MESSAGES.WITHOUT_PRIMARY_CREDIT_CARD,
            statusCode: 404,
          });
        }

        return onSuccess(paymentMethodsKillbill);
      }

      const paymentMethodsVindicia = await getPaymentMethodsVindicia({ decodedToken, configCountry });
      return onSuccess(paymentMethodsVindicia);
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    consultPaymentMethods,
  };
};

module.exports = consultPaymentMethodsWrapper;

