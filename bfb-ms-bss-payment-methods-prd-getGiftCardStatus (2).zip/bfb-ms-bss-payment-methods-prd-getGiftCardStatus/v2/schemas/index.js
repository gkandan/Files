const updatePaymentMethodSchemas = require('./updatePaymentMethodSchemas');
const giftCardRedeemValidationSchema = require('./giftCardRedeemValidationSchema');

module.exports = {
  updatePaymentMethodSchemas,
  giftCardRedeemValidationSchema,
};
