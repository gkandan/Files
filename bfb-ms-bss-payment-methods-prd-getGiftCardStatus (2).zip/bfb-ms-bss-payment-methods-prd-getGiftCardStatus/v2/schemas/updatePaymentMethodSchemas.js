const Joi = require('joi');

module.exports = {
  updatePaymentMethodSchemaVindicia: Joi.object({
    federalTaxId: Joi.string().optional(),
    payment_methods: Joi.object({
      data: Joi.array().items(Joi.object({
        vid: Joi.string().required(),
        id: Joi.string().required(),
      })),
    }),
  }),
  updatePaymentMethodSchemaKillbill: Joi.object({
    federalTaxId: Joi.string().optional(),
    payment_methods: Joi.object({
      data: Joi.array().items(Joi.object({
        id: Joi.string().required(),
        token: Joi.string().required(),
        transaction_id: Joi.string().allow(null).allow('').optional(),
        card_name: Joi.string().required(),
        card_document: Joi.string().allow(null).allow('').optional(),
        card_flag: Joi.string().required(),
        card_mask: Joi.string().required(),
        card_expire: Joi.string().required(),
        origin: Joi.string().required(),
      })),
    }),
  }),
};
