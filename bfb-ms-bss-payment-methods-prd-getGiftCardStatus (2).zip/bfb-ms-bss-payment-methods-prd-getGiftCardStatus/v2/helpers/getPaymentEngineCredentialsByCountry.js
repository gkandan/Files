const getPaymentEngineCredentialsByCountry = ({ paymentEngineCredentials, country }) => {
  const apiKey = `${country}_apikey`;
  const userName = `${country}_username`;
  const password = `${country}_password`;

  return {
    apikey: paymentEngineCredentials[apiKey],
    username: paymentEngineCredentials[userName],
    password: paymentEngineCredentials[password],
  };
};

module.exports = getPaymentEngineCredentialsByCountry;
