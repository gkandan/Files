const getKillBillConfigByCountry = async (
  { config, secretManager, decodedToken },
) => {
  await config.getKillBillConfiguration(config, secretManager);
  const country = decodedToken.iso2Code;
  const secretValues = config.killbill.credentials;

  const configByCountry = Object.entries(secretValues)
    .filter(([key]) => key.startsWith(`${country}_`))
    .reduce((object, [key, value]) => {
      const newKey = key.replace(`${country}_`, '');
      object[newKey] = value;
      return object;
    }, {});

  return {
    ...configByCountry,
    url: config.killbill.endpoint,
  };
};

module.exports = getKillBillConfigByCountry;
