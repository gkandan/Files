const giftCardRedeemWrapper = (adapters, applicatioName, config, responseHandler) => {

  const redeem = request => {

    let payload = {
      applicationName: applicatioName,
      eventSource: applicatioName,
    };
    if (request.source) {
      payload.eventSource = request.source;
    }
    if (request.queryStringParameters) {
      payload.queryStringParameters = request.queryStringParameters;
    }
    if (request) {
      payload = {
        ...payload,
        ...request,
      };
    }


    return adapters.giftCardRedeem({
      payload,
      headers: {
        ...request.headers,
      },

      onSuccess: data => {
        const response = responseHandler.responseHandler({
          event: {
            body: request,
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
            },
          },
          response: data,
          config,
          data,
          start: new Date(),
        });
        return response;
      },
      onError: error => {
        const response = responseHandler.errorHandler({
          event: {
            body: request,
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
            },
          },
          config,
          start: new Date(),
          error,
        });
        return response;
      },
    });
  };
  return {
    redeem,
  };
};

module.exports = giftCardRedeemWrapper;

