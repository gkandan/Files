const consultPaymentMethodsWrapper = (adapters, applicationName, config, errorHandler, responseHandler) => {

  const consultPaymentMethods = request => {
    const payload = {
      applicationName,
      eventSource: request.source || applicationName,
      ...request,
    };
    return adapters.consultPaymentMethods({
      payload,
      headers: {
        ...request.headers,
      },
      onSuccess: data => {
        const response = responseHandler.responseHandler({
          event: {
            body: request,
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
              'Content-Length': '1600',
            },
          },
          response: data,
          config,
          data: {
            message: data,
          },
          start: new Date(),
        });
        return response;
      },

      onError: error => {
        const response = errorHandler.errorHandler({
          event: { body: request, headers: request.headers }, config, start: new Date(), error,
        });
        return response;
      },
    });
  };

  return {
    consultPaymentMethods,
  };
};

module.exports = consultPaymentMethodsWrapper;

