const application = require('../../package.json');
const updatePaymentMethodController = require('./updatePaymentMethodController');
const getPaymentMethodController = require('./getPaymentMethodController');
const consultPaymentMethodsController = require('./consultPaymentMethodsController');
const giftCardRedeemMethodController = require('./giftCardRedeemMethodController');
const getAccountCreditController = require('./getAccountCreditMethodController');

module.exports = (adapters, config, errorHandler, responseHandler) => ({
  updatePaymentMethod: updatePaymentMethodController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).updatePaymentMethod,
  consultPaymentMethods: consultPaymentMethodsController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).consultPaymentMethods,
  getPaymentMethod: getPaymentMethodController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).getPaymentMethod,
  giftCardRedeem: giftCardRedeemMethodController(
    adapters,
    application.name,
    config,
    responseHandler,
  ).redeem,
  getAccountCredit: getAccountCreditController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).getAccountCredit,
});
