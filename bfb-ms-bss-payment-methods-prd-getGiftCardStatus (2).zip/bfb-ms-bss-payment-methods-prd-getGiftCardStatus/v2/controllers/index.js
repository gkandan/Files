const { Errors: { CustomError, StatusCode } } = require('@dtvgo-be/pkg_dtv_core');
const factory = require('./factory');
const config = require('../../config');
const schemas = require('../schemas');
const helpers = require('../helpers');
const services = require('../../services');
const errorHandler = require('../../commons/utils');
const responseHandler = require('../../commons/utils');
const commons = require('../../commons/utils');
const repositoryMongoDb = require('../repository/mongo');
const mongo = require('../../commons/lib/mongoDb');
const { responseCodes, upcMap } = require('../../commons/utils');
const secretManager = require('../../commons/lib/secretManager')({});
const dd = require('../../commons/utils/dd');

const adapters = require('../adapters')({
  config,
  schemas,
  errorHandler,
  responseHandler,
  services,
  commons,
  repositoryMongoDb,
  mongo,
  responseCodes,
  upcMap,
  helpers,
  CustomError,
  StatusCode,
  secretManager,
  dd,
});

module.exports = factory(
  adapters,
  config,
  errorHandler,
  responseHandler,
  services,
  commons,
);
