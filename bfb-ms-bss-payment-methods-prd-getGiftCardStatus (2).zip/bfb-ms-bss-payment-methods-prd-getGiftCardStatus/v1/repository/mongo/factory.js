const crypto = require('crypto');

const defaultProjection = {
  projection: {
    _id: 0,
  },
};
const defaultUpdateConfigs = ({
  upsert: false,
  multi: true,
});
const defaultFindUpdateConfig = ({
  new: true,
  fields: { _id: 0 },
});

module.exports = ({ db, collectionName }) => ({
  insert: async item => {
    const collection = await db.collection(collectionName);
    const result = collection.insertOne({ _id: crypto.randomUUID(), ...item });
    return result;
  },
  createOrUpdateWithWhere: async (filter, data) => {
    const collection = await db.collection(collectionName);
    return collection.update(filter, data, { upsert: true });
  },
  update: async (filter, item, configs = defaultUpdateConfigs) => {
    const collection = await db.collection(collectionName);
    return collection.update(filter, item, configs);
  },
  updateAndFind: async (filter, item, config = defaultFindUpdateConfig, sort = []) => {
    const collection = await db.collection(collectionName);
    const result = await collection.findAndModify(filter, sort, item, config);
    return result.value;
  },
  findOne: async (filter, projection = defaultProjection) => {
    const collection = await db.collection(collectionName);
    return collection.findOne(filter, projection);
  },
  findMany: async filter => {
    const collection = await db.collection(collectionName);
    return collection.find(filter).toArray();
  },
  findWithProjection: async (filter, projection = defaultProjection) => {
    const collection = await db.collection(collectionName);
    return collection.findOne(filter, { projection });
  },
  count: async item => {
    const collection = await db.collection(collectionName);
    return collection.find(item).count();
  },
});
