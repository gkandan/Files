const factory = require('./factory');
const mongo = require('../../../commons/lib/mongoDb');
const config = require('../../../config');

module.exports = {
  gift: factory({
    db: mongo,
    collectionName: config.mongodb.collections.gift,
  }),
  bearer: factory({
    db: mongo,
    collectionName: config.mongodb.collections.bearer,
  }),
};
