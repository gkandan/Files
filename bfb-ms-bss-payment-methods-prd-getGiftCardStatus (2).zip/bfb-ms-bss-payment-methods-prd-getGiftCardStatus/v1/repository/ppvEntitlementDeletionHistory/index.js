const { randomUUID } = require('crypto');
const db = require('../../../commons/lib/dynamo');
const config = require('../../../config');

module.exports = {
  saveEntitlementDeletionAction: async ({
    country,
    preferenceId,
    vrioCustomerId,
    sku,
    createdAt,
    updatedAt,
    entitlementRemoved,
    paymentEngineToken,
  }) => {
    const { dynamoDb: { ppvEntitlementDeletionTable } }  = config;
    const currentTimestampInSeconds = Math.floor(Date.now() / 1000);
    const ttlInSeconds = currentTimestampInSeconds + (7 * 24 * 60 * 60);
    const currentTime = new Date().toISOString();

    const item = {
      id: { S: randomUUID() },
      country: { S: country },
      preferenceId: { S: preferenceId },
      vrioCustomerId: { S: vrioCustomerId },
      sku: { S: sku },
      createdAt: { S: createdAt || currentTime },
      updatedAt: { S: updatedAt || currentTime },
      ttlInSeconds: { N: ttlInSeconds.toString() },
      entitlementRemoved: { BOOL: entitlementRemoved },
      paymentEngineToken: { S: paymentEngineToken },
    };

    return db.putItem({
      tableName: ppvEntitlementDeletionTable,
      item,
    });
  },
};
