const db = require('../../../commons/lib/dynamo');
const config = require('../../../config');

module.exports = {
  createPreference: async ({
    id,
    preferenceId,
    vrioCustomerId,
    sku,
    expirationDate,
    country,
    store,
    status,
    createdAt,
    updatedAt,
  }) => {
    const { dynamoDb: { mercadoPago: { tableName } } } = config;
    const item = {
      id: { S: id },
      preferenceId: { S: preferenceId },
      vrioCustomerId: { S: vrioCustomerId },
      sku: { S: sku },
      expirationDate: { N: expirationDate.toString() },
      country: { S: country },
      store: { S: store },
      status: { S: status },
      createdAt: { S: createdAt },
      updatedAt: { S: updatedAt },
    };

    return db.putItem({
      tableName,
      item,
    });
  },
  getPreference: async ({
    id,
  }) => {
    const { dynamoDb: { mercadoPago: { tableName } } } = config;
    const key = { id: { S: id } };

    return db.getItem({
      tableName,
      key,
    });
  },
  updateOrderStatus: async ({
    id,
    status,
  }) => {
    const { dynamoDb: { mercadoPago: { tableName } } } = config;
    const key = { id: { S: id } };

    const updateExpression = 'SET #status = :status, #updatedAt = :updatedAt';

    const expressionAttributeValues = {
      ':status': { S: status },
      ':updatedAt': { S: new Date().toISOString() },
    };
    const expressionAttributeNames = {
      '#status': 'status',
      '#updatedAt': 'updatedAt',
    };

    return db.updateItem({
      tableName,
      key,
      updateExpression,
      expressionAttributeValues,
      expressionAttributeNames,
    });
  },
};
