const jwtDecode = require('jwt-decode');

const decryptToken = (
  payload,
  config,
  enums,
  CustomError,
  StatusCode,
) => {
  try {
    const decodedToken = jwtDecode(payload);
    const configCountry = decodedToken.iso2Code === enums.RESPONSE_MESSAGES.COUNTRY_OF_BR
      ? config.vindicia.BR
      : config.vindicia.LA;

    return {
      decodedToken,
      configCountry,
    };
  } catch (error) {
    throw new CustomError({
      message: enums.RESPONSE_MESSAGES.INVALID_TOKEN,
      statusCode: StatusCode.NotFound,
    });
  }
};


module.exports = decryptToken;
