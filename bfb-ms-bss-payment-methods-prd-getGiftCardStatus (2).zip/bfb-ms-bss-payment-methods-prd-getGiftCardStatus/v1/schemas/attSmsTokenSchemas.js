const Joi = require('joi');

module.exports = {
  attSmsTokenSchemasJoi: Joi.object({
    telephoneNumber: Joi.string().trim().replace(/\D/g, '').min(9)
      .max(11),
  }).required(),

};
