const Joi = require('joi');

module.exports = {
  callbackFromPaymentEngineToKillbillJoi: Joi.object({
    capture_id: Joi.string().optional(),
    transaction_id: Joi.string().required(),
    token: Joi.string().required(),
    status: Joi.string().required(),
    origin: Joi.string().required(),
    id: Joi.string().required(),
    event: Joi.string().required(),
    gateway: Joi.string().optional().default(''),
  }).required(),
};
