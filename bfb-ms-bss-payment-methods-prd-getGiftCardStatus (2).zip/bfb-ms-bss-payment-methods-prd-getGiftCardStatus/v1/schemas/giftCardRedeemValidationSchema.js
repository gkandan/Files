const Joi = require('joi');

module.exports = {
  giftCardRedeemValidationSchemaJoi: Joi.object({
    giftCardNumber: Joi.string().required(),
    source: Joi.string().required(),
    currency: Joi.string().required(),
    amount: Joi.number().required(),
  }).required(),
};
