const paymentMethodsSchemas = require('./paymentMethodsSchemas');
const updateCreditCardSchemas = require('./updateCreditCardSchemas');
const attSmsTokenSchemas = require('./attSmsTokenSchemas');
const attValidateTokenSchemas = require('./attValidateTokenSchemas');
const attPaymentMethodsSchemas = require('./attPaymentMethodsSchemas');
const giftCardValidationSchema = require('./giftCardValidationSchema');
const magentoGrantCreditSchema = require('./magentoGrantCreditValidationSchema');
const giftCardRedeemValidationSchema = require('./giftCardRedeemValidationSchema');
const callbackFromPaymentEngineToKillbillSchema = require('./callbackFromPaymentEngineToKillbillSchema');
const mercadoPagoSchema = require('./mercadoPagoSchema');

module.exports = {
  paymentMethodsSchemas,
  updateCreditCardSchemas,
  attSmsTokenSchemas,
  attValidateTokenSchemas,
  attPaymentMethodsSchemas,
  giftCardValidationSchema,
  magentoGrantCreditSchema,
  giftCardRedeemValidationSchema,
  callbackFromPaymentEngineToKillbillSchema,
  mercadoPagoSchema,
};
