const Joi = require('joi');

module.exports = {
  createPreferenceSchema: Joi.object({
    sku: Joi.string().required(),
    backUrls: Joi.object({
      success: Joi.string().required(),
      failure: Joi.string().required(),
      pending: Joi.string().optional(),
    }).required().unknown(false),
    actionName: Joi.boolean().optional(),
  }).required(),
  paymentCallbackSchema: Joi.object({
    preference_id: Joi.string().required(),
    token: Joi.string().required(),
    status: Joi.string().required().valid('valid', 'invalid'),
  }).required().unknown(true),
};
