const Joi = require('joi');

module.exports = {
  magentoGrantCreditSchemaJoi: Joi.object({
    email: Joi.string().required().email(),
    amount: Joi.number().required(),
  }).required(),
};
