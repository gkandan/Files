const Joi = require('joi');

module.exports = {
  paymentMethodsSchemas: Joi.object({

    object: Joi.string().required(),
    id: Joi.string().required(),
    type: Joi.string().required(),

    paypal: Joi.object({
      object: Joi.string().required(),
      paypal_email: Joi.string().required(),
      payer_id: Joi.string().required(),
      return_url: Joi.string().required(),
      cancel_url: Joi.string().required(),
      request_reference_id: Joi.boolean().required(),
      reference_id: Joi.string().required(),
    }).required(),

    billing_address: Joi.object({
      object: Joi.string().required(),
      postal_code: Joi.string().required(),
      district: Joi.string().required(),
      city: Joi.string().required(),
      line3: Joi.string().required(),
      line2: Joi.string().required(),
      line1: Joi.string().required(),
      name: Joi.string().required().required(),
      country: Joi.string().required(),
    }).required(),

    policy: Joi.object({
      validate: Joi.number().required(),
    }).required(),

    account_holder: Joi.string().required(),
    currency: Joi.string().required(),
  }).required(),
};
