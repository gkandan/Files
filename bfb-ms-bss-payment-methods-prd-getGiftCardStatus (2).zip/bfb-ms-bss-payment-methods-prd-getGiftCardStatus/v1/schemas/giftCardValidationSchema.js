const Joi = require('joi');

module.exports = {
  giftCardValidationSchemaJoi: Joi.object({
    giftCardNumber: Joi.string().required(),
    source: Joi.string().required(),
  }).required(),
};
