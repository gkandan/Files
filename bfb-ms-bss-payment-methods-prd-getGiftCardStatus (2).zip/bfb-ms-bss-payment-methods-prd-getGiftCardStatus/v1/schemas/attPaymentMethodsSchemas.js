const Joi = require('joi');

module.exports = {
  attPaymentMethodsSchemasJoi: Joi.object({
    telephoneNumber: Joi.string().trim().replace(/\D/g, '').min(10)
      .max(12),
    amount: Joi.string().required(),
    paymentIdTimespan: Joi.bool().required(),
  }).required(),

};
