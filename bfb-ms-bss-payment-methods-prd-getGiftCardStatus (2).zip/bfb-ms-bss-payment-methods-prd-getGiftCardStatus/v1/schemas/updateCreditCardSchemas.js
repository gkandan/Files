const Joi = require('joi');

module.exports = {
  updateCreditCardSchemas: Joi.object({
    federalTaxId: Joi.string().optional(),
    payment_methods: Joi.object({
      data: Joi.array().items(Joi.object({
        vid: Joi.string().required(),
        id: Joi.string().required(),
      })),
    }),
  }),
};
