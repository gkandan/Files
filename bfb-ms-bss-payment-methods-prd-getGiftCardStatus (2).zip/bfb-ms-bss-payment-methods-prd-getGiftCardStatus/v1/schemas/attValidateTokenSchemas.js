const Joi = require('joi');

module.exports = {
  attValidateTokenSchemasJoi: Joi.object({
    telephoneNumber: Joi.string().trim().replace(/\D/g, '').min(10)
      .max(12),
    token: Joi.string().required(),
  }).required(),

};
