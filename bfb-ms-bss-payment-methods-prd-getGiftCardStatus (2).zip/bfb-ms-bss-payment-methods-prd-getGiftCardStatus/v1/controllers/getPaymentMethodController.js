const getPaymentMethodWrapper = (adapters, applicatioName, config, errorHandler, responseHandler) => {

  const getPaymentMethod = request => {

    let payload = {
      applicationName: applicatioName,
      eventSource: applicatioName,
    };
    if (request.source) {
      payload.eventSource = request.source;
    }
    if (request.queryStringParameters) {
      payload.queryStringParameters = request.queryStringParameters;
    }
    if (request) {
      payload = {
        ...payload,
        ...request,
      };
    }

    return adapters.getPaymentMethod({
      payload,
      headers: {
        ...request.headers,
      },
      onSuccess: data => {
        const response = responseHandler.responseHandler({
          event: {
            body: request,
            headers: {
              ...request.headers,
            },
          },
          response: data,
          config,
          data: { message: data },
          start: new Date(),
        });
        return response;
      },
      onError: error => errorHandler.errorHandler({
        payload,
        event: request,
        error,
        config,
        start: new Date(),
      }),
    });
  };
  return {
    getPaymentMethod,
  };
};

module.exports = getPaymentMethodWrapper;

