const application = require('../../package.json');
const createPaymentMethodController = require('./createPaymentMethodController');
const updatePaymentMethodController = require('./updatePaymentMethodController');
const getPaymentMethodController = require('./getPaymentMethodController');
const attSmsTokenController = require('./attSmsTokenController');
const attValidateTokenController = require('./attValidateTokenController');
const attPaymentMethodsController = require('./attPaymentMethodsController');
const consultPaymentMethodsBRController = require('./consultPaymentMethodsBRController');
const giftCardStatusController = require('./giftCardStatusController');
const giftCardRedeemController = require('./giftCardRedeemController');
const vindiciaGetAccountCreditWrapper = require('./vindiciaGetAccountCreditMethodController');
const magentoGrantCreditMethodController = require('./magentoGrantCreditMethodController');
const callbackFromPaymentEngineToKillbillController = require('./callbackFromPaymentEngineToKillbillController');
const mercadoPagoPaymentCallbackController = require('./mercadoPagoPaymentCallbackController');
const mercadoPagoCreatePreferenceController = require('./mercadoPagoCreatePreferenceController');
const mercadoPagoExpirePPVController = require('./mercadoPagoExpirePPVController');
const sendPPVExpiredEntitlementToQueueController = require('./sendPPVExpiredEntitlementToQueueController');

module.exports = (adapters, config, errorHandler, responseHandler, commons) => ({
  createPaymentMethod: createPaymentMethodController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).createPaymentMethod,

  updatePaymentMethod: updatePaymentMethodController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).updatePaymentMethod,

  attSmsToken: attSmsTokenController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).attSmsToken,

  attValidateToken: attValidateTokenController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).attValidateToken,

  attPaymentMethods: attPaymentMethodsController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
    commons,
  ).attPaymentMethods,

  getPaymentMethod: getPaymentMethodController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).getPaymentMethod,

  consultPaymentMethodsBR: consultPaymentMethodsBRController(
    adapters,
    application.name,
    config,
    errorHandler,
    responseHandler,
  ).consultPaymentMethodsBR,

  giftCardStatus: giftCardStatusController(
    adapters,
    application.name,
    config,
    responseHandler,
  ).giftCardStatus,

  giftCardRedeem: giftCardRedeemController(
    adapters,
    application.name,
    config,
    responseHandler,
  ).redeem,

  vindiciaGetAccountCredit: vindiciaGetAccountCreditWrapper(
    adapters,
    application.name,
    config,
    responseHandler,
  ).getAccountCredit,

  magentoGrantCredit: magentoGrantCreditMethodController(
    adapters,
    application.name,
    config,
    responseHandler,
  ).grantCredit,

  callbackFromPaymentEngineToKillbill: callbackFromPaymentEngineToKillbillController(
    adapters,
    application.name,
    config,
    responseHandler,
  ).callbackFromPaymentEngineToKillbill,

  mercadoPagoPaymentCallback: mercadoPagoPaymentCallbackController(
    adapters,
    application.name,
    config,
    responseHandler,
  ).mercadoPagoPaymentCallback,

  createPreference: mercadoPagoCreatePreferenceController(
    adapters,
    application.name,
    config,
    responseHandler,
  ).createPreference,
  mercadoPagoExpirePPV: mercadoPagoExpirePPVController(
    adapters,
    application.name,
    config,
    responseHandler,
  ).expirePPV,
  sendPPVExpiredEntitlementToQueue: sendPPVExpiredEntitlementToQueueController(
    adapters,
    application.name,
    config,
    responseHandler,
  ).sendPPVExpiredEntitlementToQueue,
});
