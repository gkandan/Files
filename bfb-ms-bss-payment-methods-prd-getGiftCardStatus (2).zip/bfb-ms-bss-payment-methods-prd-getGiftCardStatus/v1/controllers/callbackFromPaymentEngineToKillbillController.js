const { ResponseHandler } = require('@dtvgo-be/pkg_dtv_core');

const callbackFromPaymentEngineToKillbillWrapper = (adapters, applicatioName, config, errorHandler) => {

  const callbackFromPaymentEngineToKillbill = request => {
    let payload = {
      applicationName: applicatioName,
      eventSource: applicatioName,
    };

    if (request.source) {
      payload.eventSource = request.source;
    }
    if (request.queryStringParameters) {
      payload.queryStringParameters = request.queryStringParameters;
    }
    if (request) {
      payload = {
        ...payload,
        ...request,
      };
    }

    return adapters.callbackFromPaymentEngineToKillbill({
      payload,
      headers: {
        ...request.headers,
      },

      onSuccess: data => {
        const response = ResponseHandler.successHandler({
          event: {
            body: request,
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
            },
          },
          response: data,
          config,
          data: {
            message: data,
          },
          start: new Date(),
        });
        return response;
      },

      onError: error => errorHandler.errorHandler({
        payload,
        event: request,
        error,
        config,
        start: new Date(),
      }),
    });
  };
  return {
    callbackFromPaymentEngineToKillbill,
  };
};

module.exports = callbackFromPaymentEngineToKillbillWrapper;
