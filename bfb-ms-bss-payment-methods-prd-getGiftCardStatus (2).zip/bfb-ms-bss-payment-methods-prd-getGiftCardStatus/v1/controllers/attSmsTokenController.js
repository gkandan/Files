const { ResponseHandler } = require('@dtvgo-be/pkg_dtv_core');

const attSmsTokenWrapper = (adapters, applicatioName, config, errorHandler) => {

  const attSmsToken = request => {

    let payload = {
      applicationName: applicatioName,
      eventSource: applicatioName,
    };
    if (request.source) {
      payload.eventSource = request.source;
    }
    if (request.queryStringParameters) {
      payload.queryStringParameters = request.queryStringParameters;
    }
    if (request) {
      payload = {
        ...payload,
        ...request,
      };
    }

    return adapters.attSmsToken({
      payload,
      headers: {
        ...request.headers,
      },

      onSuccess: data => {
        const response = ResponseHandler.successHandler({
          event: {
            body: request,
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
              'Content-Length': '1688',
            },
          },
          response: data,
          config,
          data: {
            message: data,
          },
          start: new Date(),
        });
        return response;
      },
      onError: error => errorHandler.errorHandler({
        payload,
        event: request,
        error,
        config,
        start: new Date(),
      }),
    });
  };
  return {
    attSmsToken,
  };
};

module.exports = attSmsTokenWrapper;

