const createPaymentMethodWrapper = (adapters, applicatioName, config, errorHandler, responseHandler) => {

  const createPaymentMethod = request => {

    let payload = {
      applicationName: applicatioName,
      eventSource: applicatioName,
    };
    if (request.source) {
      payload.eventSource = request.source;
    }
    if (request.queryStringParameters) {
      payload.queryStringParameters = request.queryStringParameters;
    }
    if (request) {
      payload = {
        ...payload,
        ...request,
      };
    }

    return adapters.createPaymentMethod({
      payload,
      headers: {
        ...request.headers,
      },

      onSuccess: data => {
        const response = responseHandler.responseHandler({
          event: {
            body: request,
            headers: request.headers,
          },
          response: data,
          config,
          data: {
            message: data,
          },
          start: new Date(),
        });
        return response;
      },

      onError: error => {
        const response = errorHandler.errorHandler({
          event: { body: request, headers: request.headers }, config, start: new Date(), error,
        });
        return response;
      },
    });
  };
  return {
    createPaymentMethod,
  };
};

module.exports = createPaymentMethodWrapper;

