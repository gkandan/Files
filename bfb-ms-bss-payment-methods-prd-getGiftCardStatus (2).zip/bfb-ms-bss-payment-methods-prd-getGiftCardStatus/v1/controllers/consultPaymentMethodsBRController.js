const consultPaymentMethodsWrapper = (adapters, applicatioName, config, errorHandler, responseHandler) => {

  const consultPaymentMethodsBR = request => {

    let payload = {
      applicationName: applicatioName,
      eventSource: applicatioName,
    };
    if (request.source) {
      payload.eventSource = request.source;
    }
    if (request.queryStringParameters) {
      payload.queryStringParameters = request.queryStringParameters;
    }
    if (request) {
      payload = {
        ...payload,
        ...request,
      };
    }

    return adapters.consultPaymentMethodsBR({
      payload,
      headers: {
        ...request.headers,
      },

      onSuccess: data => {
        const response = responseHandler.responseHandler({
          event: {
            body: request,
            headers: request.headers,
          },
          response: data,
          config,
          data: {
            message: data,
          },
          start: new Date(),
        });
        return response;
      },

      onError: error => {
        const response = errorHandler.errorHandler({
          event: { body: request, headers: request.headers }, config, start: new Date(), error,
        });
        return response;
      },

    });
  };
  return {
    consultPaymentMethodsBR,
  };
};

module.exports = consultPaymentMethodsWrapper;

