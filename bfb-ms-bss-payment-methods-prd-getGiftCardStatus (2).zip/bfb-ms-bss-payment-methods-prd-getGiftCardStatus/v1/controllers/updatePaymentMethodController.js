const updatePaymentMethodWrapper = (adapters, applicatioName, config, errorHandler, responseHandler) => {

  const updatePaymentMethod = request => {

    let payload = {
      applicationName: applicatioName,
      eventSource: applicatioName,
    };
    if (request.source) {
      payload.eventSource = request.source;
    }
    if (request.queryStringParameters) {
      payload.queryStringParameters = request.queryStringParameters;
    }
    if (request) {
      payload = {
        ...payload,
        ...request,
      };
    }

    return adapters.updatePaymentMethod({
      payload,
      headers: {
        ...request.headers,
      },

      onSuccess: data => {
        const response = responseHandler.responseHandler({
          event: {
            body: request,
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
              'Content-Length': '1600',
            },
          },
          response: data,
          config,
          data: {
            message: data,
          },
          start: new Date(),
        });
        return response;
      },

      onError: error => {
        const response = errorHandler.errorHandler({
          event: { body: request, headers: request.headers }, config, start: new Date(), error,
        });
        return response;
      },
    });
  };
  return {
    updatePaymentMethod,
  };
};

module.exports = updatePaymentMethodWrapper;

