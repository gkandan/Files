const vindiciaGetAccountCreditWrapper = (adapters, applicatioName, config, responseHandler) => {

  const getAccountCredit = request => {

    let payload = {
      applicationName: applicatioName,
      eventSource: applicatioName,
    };
    if (request.source) {
      payload.eventSource = request.source;
    }
    if (request.queryStringParameters) {
      payload.queryStringParameters = request.queryStringParameters;
    }
    if (request) {
      payload = {
        ...payload,
        ...request,
      };
    }


    return adapters.vindiciaGetAccountCredit({
      payload,
      headers: {
        ...request.headers,
      },

      onSuccess: data => {
        const response = responseHandler.responseHandler({
          event: {
            body: request,
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
              'Content-Length': '1600',
            },
          },
          response: data,
          config,
          data,
          start: new Date(),
        });
        return response;
      },
      onError: error => {
        const response = responseHandler.errorHandler({
          event: {
            body: request,
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
              'Content-Length': '1600',
            },
          },
          config,
          start: new Date(),
          error,
        });
        return response;
      },
    });
  };
  return {
    getAccountCredit,
  };
};

module.exports = vindiciaGetAccountCreditWrapper;

