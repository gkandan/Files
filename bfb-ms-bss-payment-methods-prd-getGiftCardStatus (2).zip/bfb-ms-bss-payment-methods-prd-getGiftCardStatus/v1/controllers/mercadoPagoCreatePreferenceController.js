

const { ResponseHandler } = require('@dtvgo-be/pkg_dtv_core');

const createPreferenceWrapper = (adapters, applicationName, config) => {

  const createPreference = request => {
    const payload = {
      applicationName,
      eventSource: request.source || applicationName,
      ...request,
    };

    return adapters.createPreference({
      payload,
      onSuccess: data => {
        const response = ResponseHandler.successHandler({
          event: {
            body: {
              ...request,
            },
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
            },
          },
          response: data,
          config,
          data,
          start: new Date(),
        });

        // added due to a serverless-offline issue, the content length is not being overriden
        delete response.headers['Content-Length'];

        return response;
      },

      onError: error => {
        const headers = {
          ...request.headers,
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': true,
        };
        const response = ResponseHandler.errorHandler({
          event: {
            body: {
              ...request,
            },
            headers,
          },
          config,
          start: new Date(),
          error,
        });

        return {
          ...response,
          headers,
        };

      },
    });
  };

  return {
    createPreference,
  };
};

module.exports = createPreferenceWrapper;

