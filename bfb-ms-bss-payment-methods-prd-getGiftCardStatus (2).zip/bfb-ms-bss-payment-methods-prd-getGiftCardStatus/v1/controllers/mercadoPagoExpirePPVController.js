

const { ResponseHandler } = require('@dtvgo-be/pkg_dtv_core');

const expirePPVWrapper = (adapters, applicationName, config) => {

  const expirePPV = request => {
    const payload = {
      applicationName,
      eventSource: request.source || applicationName,
      ...request,
    };

    return adapters.expirePPV({
      payload,
      onSuccess: data => {
        const response = ResponseHandler.successHandler({
          event: {
            body: {
              ...request,
            },
            headers: {
              ...request.headers,
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Credentials': true,
            },
          },
          response: data,
          config,
          data,
          start: new Date(),
        });
        return response;
      },

      onError: error => {
        const headers = {
          ...request.headers,
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': true,
        };
        const response = ResponseHandler.errorHandler({
          event: {
            body: {
              ...request,
            },
            headers,
          },
          config,
          start: new Date(),
          error,
        });
        return {
          ...response,
          headers,
        };

      },
    });
  };

  return {
    expirePPV,
  };
};

module.exports = expirePPVWrapper;

