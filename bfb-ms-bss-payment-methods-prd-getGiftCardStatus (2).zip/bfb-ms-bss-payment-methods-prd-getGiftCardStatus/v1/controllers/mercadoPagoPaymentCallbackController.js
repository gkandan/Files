const { ResponseHandler } = require('@dtvgo-be/pkg_dtv_core');

const paymentCallbackWrapper = (adapters, applicationName, config) => {

  const mercadoPagoPaymentCallback = request => {
    const payload = {
      applicationName,
      eventSource: request.source || applicationName,
      ...request,
    };

    return adapters.callbackFromPaymentEngineToMagento({
      payload,
      onSuccess: data => {
        const response = ResponseHandler.successHandler({
          event: {
            ...request,
            headers: {
              ...request.headers,
              'Content-Length': undefined,
            },
          },
          response: data,
          config,
          data,
          start: new Date(),
        });
        return response;
      },

      onError: error => {
        const response = ResponseHandler.errorHandler({
          event: {
            ...request,
            headers: {
              ...request.headers,
            },
          },
          config,
          start: new Date(),
          error,
        });
        return response;

      },
    });
  };

  return {
    mercadoPagoPaymentCallback,
  };
};

module.exports = paymentCallbackWrapper;
