const { CustomError } = require('@dtvgo-be/pkg_dtv_core/helpers/customError');

const attSmsTokenWrapper = ({
  attValidateTelephoneService,
  attSmsTokenService,
  attSmsTokenSchemas,
  config,
  commons: { enums },
}) => {
  const attSmsToken = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const { error } = await attSmsTokenSchemas.validate(payload.pathParameters);
      if (error) {
        throw new CustomError({ message: enums.RESPONSE_MESSAGES.INVALID_PARAMETER });
      }

      const resTelephone = await attValidateTelephoneService
        .attValidateTelephone(payload.pathParameters.telephoneNumber, config.attmx);

      if (resTelephone.ErrorInfo) {
        throw new CustomError({
          message: `${resTelephone.ErrorInfo.errorMessage}`,
          errorCode: resTelephone.ErrorInfo.errorCode,
        });
      }

      if (typeof resTelephone.BasicUserInfoResponse === 'undefined') {
        throw new CustomError({
          message: enums.RESPONSE_MESSAGES.RESPONSE_UNDEFINED,
          statusCode: 400,
        });
      }

      if (resTelephone.BasicUserInfoResponse.status === enums.RESPONSE_MESSAGES.NOT_PAID) {
        throw new CustomError({
          message: enums.RESPONSE_MESSAGES.NOT_PAID_MESSAGE,
          statusCode: 402,
        });
      }

      if (resTelephone.BasicUserInfoResponse.status === enums.RESPONSE_MESSAGES.ACTIVO) {

        const payloadSmsToken = {
          smsTokenRequest: {
            sourceChannel: enums.RESPONSE_MESSAGES.SOURCE_CHANNEL,
            telephoneNumber: payload.pathParameters.telephoneNumber,
          },
        };

        const resSendSmsToken = await attSmsTokenService
          .attSmsToken(payloadSmsToken, config.attmx);

        if (typeof resSendSmsToken.smsTokenResponse === 'undefined'
          || resSendSmsToken.smsTokenResponse.responseCode === enums.RESPONSE_MESSAGES.EE0
          || resSendSmsToken.smsTokenResponse.responseCode === enums.RESPONSE_MESSAGES.EE1
        ) {
          throw new CustomError({
            message: enums.RESPONSE_MESSAGES.RESPONSE_UNDEFINED,
            statusCode: 400,
          });
        }

        const res = {
          resSendCode: resSendSmsToken.smsTokenResponse.responseCode,
          responseMessage: enums.RESPONSE_MESSAGES.SEND_SMS_WITH_SUCCESS,
        };
        return onSuccess(res);
      }

      throw new CustomError({
        resTelephone,
        message: enums.RESPONSE_MESSAGES.INTERNAL_SERVER_ERROR,
        statusCode: 500,
      });

    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };

  return {
    attSmsToken,
  };

};

module.exports = attSmsTokenWrapper;
