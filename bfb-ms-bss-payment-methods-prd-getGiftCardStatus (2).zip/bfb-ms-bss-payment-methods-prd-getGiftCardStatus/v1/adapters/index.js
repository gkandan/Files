const crypto = require('crypto');
const createPaymentMethodWrapper = require('./createPaymentMethod');
const updatePaymentMethodWrapper = require('./updatePaymentMethod');
const attSmsTokenWrapper = require('./attSmsToken');
const attValidateTokenWrapper = require('./attValidateToken');
const attPaymentMethodsWrapper = require('./attPaymentMethods');
const getPaymentMethodWrapper = require('./getPaymentMethodInSubscription');
const consultPaymentMethodsWrapper = require('./consultPaymentMethod/consultPaymentMethodAdapters');
const giftCardStatusWrapper = require('./giftCardStatusMethod');
const giftCardRedeemWrapper = require('./giftCardRedeemMethod');
const vindiciaGetAccountCreditWrapper = require('./vindiciaGetAccountCreditMethod');
const magentoGrantCreditWrapper = require('./magentoGrantCreditMethod');
const callbackFromPaymentEngineToKillbillWrapper = require('./callbackFromPaymentEngineToKillbill');
const mercadoPagoPaymentCallbackWrapper = require('./mercadoPago/paymentCallback');
const mercadoPagoCreatePreferenceWrapper = require('./mercadoPago/createPreference');
const expirePPVWrapper = require('./mercadoPago/expirePPV');
const sendPPVExpiredEntitlementToQueueWrapper = require('./mercadoPago/sendPPVExpiredEntitlementToQueue');

module.exports = dependencies => ({
  createPaymentMethod: createPaymentMethodWrapper({
    paymentMethodsSchemas: dependencies.schemas.paymentMethodsSchemas.paymentMethodsSchemas,
    createPaymentMethodService: dependencies.services.createPaymentMethodService,
    config: dependencies.config,
    commons: dependencies.commons,
  }).createPaymentMethod,

  updatePaymentMethod: updatePaymentMethodWrapper({
    updateCreditCardSchemas: dependencies.schemas.updateCreditCardSchemas.updateCreditCardSchemas,
    updatePaymentMethodService: dependencies.services.updatePaymentMethodService,
    updateAccountService: dependencies.services.updateAccountService,
    helpers: dependencies.helpers,
    config: dependencies.config,
    commons: dependencies.commons,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
  }).updatePaymentMethod,

  attSmsToken: attSmsTokenWrapper({
    attSmsTokenSchemas: dependencies.schemas.attSmsTokenSchemas.attSmsTokenSchemasJoi,
    attValidateTelephoneService: dependencies.services.attValidateTelephoneService,
    attSmsTokenService: dependencies.services.attSmsTokenService,
    config: dependencies.config,
    commons: dependencies.commons,
  }).attSmsToken,

  attValidateToken: attValidateTokenWrapper({
    attValidateTokenSchemas: dependencies.schemas.attValidateTokenSchemas.attValidateTokenSchemasJoi,
    attValidateTokenService: dependencies.services.attValidateTokenService,
    attCheckExternalIdService: dependencies.services.attCheckExternalIdService,
    config: dependencies.config,
    commons: dependencies.commons,
  }).attValidateToken,

  attPaymentMethods: attPaymentMethodsWrapper({
    attPaymentMethodsSchemas: dependencies.schemas.attPaymentMethodsSchemas.attPaymentMethodsSchemasJoi,
    attPaymentMethodsService: dependencies.services.attPaymentMethodsService,
    attPaymentExecuteService: dependencies.services.attPaymentExecuteService,
    config: dependencies.config,
    commons: dependencies.commons,
  }).attPaymentMethods,

  getPaymentMethod: getPaymentMethodWrapper({
    getPaymentMethodService: dependencies.services.getPaymentMethodService,
    helpers: dependencies.helpers,
    config: dependencies.config,
    commons: dependencies.commons,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
  }).getPaymentMethod,

  consultPaymentMethodsBR: consultPaymentMethodsWrapper({
    consultPaymentMethodsBRService: dependencies.services.consultPaymentMethodsBRService,
    helpers: dependencies.helpers,
    config: dependencies.config,
    commons: dependencies.commons,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
  }).consultPaymentMethodsBR,

  giftCardStatus: giftCardStatusWrapper({
    giftCardValidationSchema: dependencies.schemas.giftCardValidationSchema.giftCardValidationSchemaJoi,
    giftCardStatusService: dependencies.services.giftCardStatusService,
    giftCardStatusDGoValidator: dependencies.services.giftCardStatusDGoValidator,
    giftCardAuthService: dependencies.services.giftCardAuthService,
    config: dependencies.config,
    repository: dependencies.repositoryMongoDb,
    db: dependencies.mongo,
    responseCodes: dependencies.responseCodes,
    upcMap: dependencies.upcMap,
    crypto: crypto,
    commons: dependencies.commons,
  }).giftCardStatus,

  giftCardRedeem: giftCardRedeemWrapper({
    giftCardRedeemValidationSchema: dependencies.schemas.giftCardRedeemValidationSchema.giftCardRedeemValidationSchemaJoi,
    vindiciaGrantCreditService: dependencies.services.vindiciaGrantCreditService,
    giftCardRedeemService: dependencies.services.giftCardRedeemService,
    giftCardCancelService: dependencies.services.giftCardCancelService,
    giftCardAuthService: dependencies.services.giftCardAuthService,
    giftCardStatusDGoRecorder: dependencies.services.giftCardStatusDGoRecorder,
    responseCodes: dependencies.responseCodes,
    config: dependencies.config,
    repository: dependencies.repositoryMongoDb,
    db: dependencies.mongo,
    crypto: crypto,
    commons: dependencies.commons,
    helpers: dependencies.helpers,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
  }).redeem,

  vindiciaGetAccountCredit: vindiciaGetAccountCreditWrapper({
    vindiciaGetAccountService: dependencies.services.vindiciaGetAccountService,
    config: dependencies.config,
    commons: dependencies.commons,
    helpers: dependencies.helpers,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
  }).getAccountCredit,

  grantCredit: magentoGrantCreditWrapper({
    magentoGrantCreditSchema: dependencies.schemas.magentoGrantCreditSchema.magentoGrantCreditSchemaJoi,
    magentoGrantCreditService: dependencies.services.magentoGrantCreditService,
    config: dependencies.config,
    commons: dependencies.commons,
  }).grantCredit,

  callbackFromPaymentEngineToKillbill: callbackFromPaymentEngineToKillbillWrapper({
    config: dependencies.config,
    commons: dependencies.commons,
    killBillService: dependencies.services.killBillService,
    enums: dependencies.enums,
    helpers: dependencies.helpers,
    secretManager: dependencies.secretManager,
    CustomError: dependencies.CustomError,
    callbackFromPaymentEngineToKillbillSchema: dependencies.schemas
      .callbackFromPaymentEngineToKillbillSchema.callbackFromPaymentEngineToKillbillJoi,
  }).callbackFromPaymentEngineToKillbill,

  callbackFromPaymentEngineToMagento: mercadoPagoPaymentCallbackWrapper({
    config: dependencies.config,
    commons: dependencies.commons,
    repositoryStoreOrders: dependencies.repositoryStoreOrders,
    magentoService: dependencies.services.magentoService,
    pnlService: dependencies.services.pnlService,
    enums: dependencies.enums,
    helpers: dependencies.helpers,
    secretManager: dependencies.secretManager,
    CustomError: dependencies.CustomError,
    schemas: dependencies.schemas,
    StatusCode: dependencies.StatusCode,
  }),
  createPreference: mercadoPagoCreatePreferenceWrapper({
    config: dependencies.config,
    commons: dependencies.commons,
    enums: dependencies.enums,
    helpers: dependencies.helpers,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
    services: dependencies.services,
    repositoryStoreOrders: dependencies.repositoryStoreOrders,
    schemas: dependencies.schemas,
  }),
  expirePPV: expirePPVWrapper({
    config: dependencies.config,
    commons: dependencies.commons,
    enums: dependencies.enums,
    helpers: dependencies.helpers,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
    services: dependencies.services,
    repositoryEntitlementDeletionHistory: dependencies.repositoryEntitlementDeletionHistory,
    schemas: dependencies.schemas,
  }),
  sendPPVExpiredEntitlementToQueue: sendPPVExpiredEntitlementToQueueWrapper({
    enums: dependencies.enums,
    CustomError: dependencies.CustomError,
    StatusCode: dependencies.StatusCode,
    sqs: dependencies.sqs,
    config: dependencies.config,
  }),
});
