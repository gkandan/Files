const vindiciaGetAccountCreditWrapper = ({
  vindiciaGetAccountService,
  helpers,
  config,
  commons: { enums },
  CustomError,
  StatusCode,
}) => {
  const getAccountCredit = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const { Authorization } = payload.headers;

      const { decodedToken, configCountry } = await helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      const account = await vindiciaGetAccountService
        .getAccount(decodedToken.customerId, configCountry);

      let result = [];

      if (account && account.credit && account.credit.currency_amounts && account.credit.currency_amounts.data) {
        result = account.credit.currency_amounts.data;
      }

      return onSuccess(result);
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    getAccountCredit,
  };
};

module.exports = vindiciaGetAccountCreditWrapper;
