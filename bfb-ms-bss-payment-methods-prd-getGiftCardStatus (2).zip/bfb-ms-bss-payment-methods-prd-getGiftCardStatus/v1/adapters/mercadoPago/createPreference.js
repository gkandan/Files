

const createPreferenceWrapper = ({
  repositoryStoreOrders,
  config,
  services: {
    paymentEngineCheckoutService,
    magentoGraphQLService,
  },
  enums,
  helpers,
  CustomError,
  StatusCode,
  schemas,
}) => {
  const parseUserInfo = token => {
    try {
      const { decodedToken } = helpers.decryptToken(token, config, enums, CustomError, StatusCode);
      const {
        vrioCustomerId, email, sub, name, iso2Code: country, businessUnit,
      } = decodedToken;
      return {
        vrioCustomerId,
        email: email || sub,
        name,
        country,
        businessUnit,
      };
    } catch (error) {
      throw new CustomError({
        message: enums.RESPONSE_MESSAGES.MERCADO_PAGO_FAILED_TO_PARSE_USER_INFO,
        statusCode: StatusCode.BadRequest,
        additionalData: {
          status: enums.MERCADO_PAGO_ERROR_STATUS.FAILED_TO_PARSE_USER_INFO,
        },
      });
    }
  };

  const convertISOToUnixTimestamp = date => Math.floor(date.getTime() / 1000);

  const convertStringDateToISO = stringDate => {
    const isoStringDate = `${stringDate.trim().replace(' ', 'T')}Z`;

    const isoDate = new Date(isoStringDate);

    return isoDate.toISOString();
  };

  const selectActionName = ({ country, customActionName }) => {
    if (config.paymentEngineCheckout.customActionNameEnabled && customActionName) {
      return customActionName;
    }

    return config.paymentEngineCheckout.secretsManagerCheckoutConfig[`${country}_${enums.PAYMENT_ENGINE_CHECKOUT.ACTION_NAME}`];
  };

  const buildCheckoutPayload = ({
    sku,
    user,
    product,
    backUrls,
    customActionName,
  }) => {
    const {
      success: successUrl,
      failure: failureUrl,
      pending: pendingUrl,
    } = backUrls;
    const {
      vrioCustomerId, name, email, country,
    } = user;
    const {
      description, amount, quantity, expiration,
    } = product;

    const actionName = selectActionName({ country, customActionName });

    return {
      customer: {
        name,
        email,
      },
      payments: {
        items: [{
          description,
          amount,
          quantity,
        }],
        start_date: new Date().toISOString(),
        end_date: expiration,
      },
      request: {
        origin: `ecommerce_${country.toLowerCase()}`,
        id: `${vrioCustomerId}|${sku}|${convertISOToUnixTimestamp(new Date())}`,
        action: actionName,
        async: false,
        back_url_success: successUrl,
        back_url_failure: failureUrl,
        ...(pendingUrl ? { back_url_pending: pendingUrl } : {}),
        event_date: expiration,
      },
    };
  };

  const convertPrice = price => Number(price.replace('.', '').replace(',', ''));

  const getProductDetails = async ({ sku, countryCode }) => {
    try {
      const { data: { products: { items } } } = await magentoGraphQLService.getProductBySKUWithCache({ sku, countryCode });
      if (!items.length) {
        throw new CustomError({
          message: enums.RESPONSE_MESSAGES.MERCADO_PAGO_PRODUCT_NOT_FOUND,
          statusCode: StatusCode.NotFound,
          additionalData: {
            status: enums.MERCADO_PAGO_ERROR_STATUS.PRODUCT_NOT_FOUND,
          },
        });
      }

      const [{
        name: description,
        customAttributes,
        price_range: { minimum_price: { final_price: { value } } },
      }] = items;

      const {
        event_expiration_date: eventExpirationDate,
        entitlement_expiration_date: entitlementExpirationDate,
      } = JSON.parse(customAttributes);

      const entitlementRemoveDate = convertStringDateToISO(entitlementExpirationDate);

      return {
        description,
        amount: convertPrice(value),
        quantity: 1,
        expiration: convertStringDateToISO(eventExpirationDate),
        removeEntitlementAt: Number(convertISOToUnixTimestamp(new Date(entitlementRemoveDate))),
      };
    } catch (error) {
      if (error instanceof CustomError) {
        throw error;
      }

      throw new CustomError({
        message: enums.RESPONSE_MESSAGES.MERCADO_PAGO_PRODUCT_NOT_FOUND,
        statusCode: StatusCode.NotFound,
        additionalData: {
          status: enums.MERCADO_PAGO_ERROR_STATUS.PRODUCT_NOT_FOUND,
        },
      });
    }
  };

  const buildStoreOrder = ({
    id,
    preferenceId,
    sku,
    product,
    user,
  }) => {
    const {
      removeEntitlementAt,
    } = product;
    const {
      vrioCustomerId, country,
    } = user;

    const store = config.paymentEngineCheckout.secretsManagerCheckoutConfig[`${country}_${enums.PAYMENT_ENGINE_CHECKOUT.STORE}`];

    return {
      id,
      preferenceId,
      vrioCustomerId,
      expirationDate: removeEntitlementAt,
      status: enums.MERCADO_PAGO_CHECKOUT_STATUS.PROCESSING,
      store,
      sku,
      country,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  };

  const validateCountry = ({ user }) => {
    const { paymentEngineCheckout: { allowedCountries } } = config;
    if (!allowedCountries.includes(user.country)) {
      throw new CustomError({
        message: enums.RESPONSE_MESSAGES.MERCADO_PAGO_COUNTRY_NOT_SUPPORTED,
        statusCode: StatusCode.BadRequest,
        additionalData: {
          status: enums.MERCADO_PAGO_ERROR_STATUS.COUNTRY_NOT_SUPPORTED,
        },
      });
    }
  };

  const validateBusinessUnit = ({ user }) => {
    const { paymentEngineCheckout: { allowedBusinessUnit } } = config;
    if (!allowedBusinessUnit.includes(user.businessUnit)) {
      throw new CustomError({
        message: enums.RESPONSE_MESSAGES.BUSINESS_UNIT_IS_NOT_ALLOWED,
        statusCode: StatusCode.Forbidden,
        additionalData: {
          status: enums.MERCADO_PAGO_ERROR_STATUS.BUSINESS_UNIT_IS_NOT_ALLOWED,
        },
      });
    }
  };

  const handler = async ({ payload, onSuccess, onError }) => {
    try {
      const { sku, backUrls, actionName } = JSON.parse(payload.body);
      const { headers: { Authorization } } = payload;

      const { error: validationError } = await schemas.mercadoPagoSchema
        .createPreferenceSchema.validate({ sku, backUrls });
      if (validationError) {
        throw new CustomError({
          message: enums.RESPONSE_MESSAGES.MERCADO_PAGO_MISSING_PARAMETER,
          statusCode: StatusCode.BadRequest,
          additionalData: {
            status: enums.MERCADO_PAGO_ERROR_STATUS.MISSING_PARAMETER,
          },
        });
      }

      const user = parseUserInfo(Authorization);

      validateCountry({ user });
      validateBusinessUnit({ user });

      const product = await getProductDetails({ sku, countryCode: user.country });
      const checkoutPayload = buildCheckoutPayload({
        sku, user, product, backUrls, customActionName: actionName,
      });
      const { preference_id: preferenceId, token } = await paymentEngineCheckoutService.checkout({
        payload: checkoutPayload,
        countryCode: user.country,
      });

      const storeOrder = buildStoreOrder({
        id: token,
        preferenceId,
        sku,
        product,
        user,
      });

      try {
        await repositoryStoreOrders.createPreference(storeOrder);
      } catch (error) {
        throw new CustomError({
          message: enums.RESPONSE_MESSAGES.MERCADO_PAGO_FAILED_TO_STORE_ORDER,
          statusCode: StatusCode.InternalServerError,
          additionalData: {
            status: enums.MERCADO_PAGO_ERROR_STATUS.FAILED_TO_STORE_ORDER,
          },
          error,
        });
      }

      return onSuccess({
        preferenceId,
      });
    } catch (error) {
      if (error instanceof CustomError) {
        if (!error.additionalData?.status) {
          error.additionalData ??= {};
          error.additionalData.status = enums.MERCADO_PAGO_ERROR_STATUS.GENERAL_ERROR;
        }
        return onError(error);
      }

      return onError(new CustomError({
        message: error.message,
        statusCode: StatusCode.InternalServerError,
        additionalData: {
          status: enums.MERCADO_PAGO_ERROR_STATUS.GENERAL_ERROR,
        },
        error,
      }));
    }
  };

  return handler;
};

module.exports = createPreferenceWrapper;
