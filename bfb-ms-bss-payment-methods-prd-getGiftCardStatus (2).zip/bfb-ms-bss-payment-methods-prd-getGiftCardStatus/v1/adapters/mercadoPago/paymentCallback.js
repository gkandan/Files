const callbackFromPaymentEngineToMagentoWrapper = ({
  repositoryStoreOrders,
  enums,
  CustomError,
  magentoService,
  pnlService,
  schemas,
  StatusCode,
}) => {
  const isStatusCompleted = status => status === enums.MERCADO_PAGO_PE_CHECKOUT_STATUS.VALID;

  const translateStatus = status => {
    if (isStatusCompleted(status)) {
      return enums.MERCADO_PAGO_CHECKOUT_STATUS.COMPLETED;
    }

    return enums.MERCADO_PAGO_CHECKOUT_STATUS.FAILED;
  };

  const handler = async ({ payload, onSuccess, onError }) => {
    try {
      const body = JSON.parse(payload.body);
      const { error: validationError } = schemas.mercadoPagoSchema.paymentCallbackSchema.validate(body);
      if (validationError) {
        throw new CustomError({
          message: validationError.message,
          statusCode: StatusCode.BadRequest,
        });
      }

      const { preference_id: preferenceId, token: id, status: payloadStatus } = body;
      const status = translateStatus(payloadStatus);

      const order = await repositoryStoreOrders.getPreference({ id });
      if (!order) {
        throw new CustomError({
          message: enums.RESPONSE_MESSAGES.MERCADO_PAGO_PAYMENT_CALLBACK_PREFERENCE_NOT_FOUND,
          statusCode: StatusCode.NotFound,
        });
      }
      const {
        store,
        orderNumber,
        country,
        sku,
        vrioCustomerId,
        status: currentStatus,
      } = order;

      if (currentStatus === status) {
        return onSuccess({
          message: enums.RESPONSE_MESSAGES.MERCADO_PAGO_PAYMENT_CALLBACK_STATUS_ALREADY_UPDATED,
        });
      }

      if (orderNumber) {
        await magentoService.updateOrderStatus({
          store,
          entity_id: orderNumber,
          state: status,
          status,
        });
      }

      const isCompleted = isStatusCompleted(payloadStatus);
      if (isCompleted) {
        await pnlService.addMercadoPagoEntitlement({
          country,
          vrioCustomerId,
          preferenceId,
          sku,
        });
      }

      await repositoryStoreOrders.updateOrderStatus({
        id,
        status,
      });

      return onSuccess({
        message: enums.RESPONSE_MESSAGES.MERCADO_PAGO_PAYMENT_CALLBACK_STATUS_UPDATED,
      });
    } catch (error) {
      if (error instanceof CustomError) {
        return onError(error);
      }

      return onError(new CustomError({
        message: enums.INTERNAL_SERVER_ERROR,
        statusCode: StatusCode.InternalServerError,
        error,
      }));
    }
  };

  return handler;
};

module.exports = callbackFromPaymentEngineToMagentoWrapper;
