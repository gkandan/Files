

const sendPPVExpiredEntitlementToQueueWrapper = ({
  enums,
  CustomError,
  StatusCode,
  sqs,
  config,
}) => {

  const parseDynamoStreamPayload = ({ Records }) => Records.map(({ dynamodb }) => {
    const { OldImage } = dynamodb;
    const {
      id: { S: id },
      country: { S: country },
      preferenceId: { S: preferenceId },
      vrioCustomerId: { S: vrioCustomerId },
      sku: { S: sku },
    } = OldImage;

    return {
      id,
      country,
      preferenceId,
      vrioCustomerId,
      sku,
    };
  });

  const handler = async ({ payload, onSuccess, onError }) => {
    try {
      const entitlementsToRemove = parseDynamoStreamPayload(payload);

      await sqs.sendMessage({
        message: entitlementsToRemove,
        queueUrl: config.sqs.entitlementsToRemoveQueue,
      });

      return onSuccess({
        message: enums.RESPONSE_MESSAGES.SUCCESS,
      });
    } catch (error) {
      return onError(new CustomError({
        message: error.message,
        statusCode: StatusCode.InternalServerError,
        error,
      }));
    }
  };

  return handler;
};

module.exports = sendPPVExpiredEntitlementToQueueWrapper;
