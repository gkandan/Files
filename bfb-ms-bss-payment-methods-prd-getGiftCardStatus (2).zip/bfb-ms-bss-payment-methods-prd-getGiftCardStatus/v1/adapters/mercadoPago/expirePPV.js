

const expirePPVWrapper = ({
  services: {
    pnlService,
  },
  enums,
  CustomError,
  StatusCode,
  repositoryEntitlementDeletionHistory,
}) => {
  const isRejected = promise => promise.status === enums.PROMISE_STATUS.REJECTED;

  const parseSqsPayload = ({ Records }) => Records.flatMap(data => JSON.parse(data.body));

  const processRemoveEntitlement = async ({
    country, vrioCustomerId, preferenceId, sku, id,
  }) => {
    try {
      await pnlService.removeMercadoPagoEntitlement({
        country,
        vrioCustomerId,
        preferenceId,
        sku,
      });

      await repositoryEntitlementDeletionHistory.saveEntitlementDeletionAction({
        country,
        vrioCustomerId,
        preferenceId,
        sku,
        entitlementRemoved: true,
        paymentEngineToken: id,
      });
    } catch (error) {
      await repositoryEntitlementDeletionHistory.saveEntitlementDeletionAction({
        country,
        vrioCustomerId,
        preferenceId,
        sku,
        entitlementRemoved: false,
        paymentEngineToken: id,
      });

      throw new CustomError({
        message: error.message,
        statusCode: error.statusCode || StatusCode.InternalServerError,
        error,
        additionalData: {
          country,
          vrioCustomerId,
          preferenceId,
          sku,
        },
      });
    }
  };

  const handler = async ({ payload, onSuccess, onError }) => {
    try {
      const entitlementsToRemove = parseSqsPayload(payload);
      const results = await Promise.allSettled(entitlementsToRemove.map(processRemoveEntitlement));

      const failedResults = results
        .filter(isRejected)
        .map(({ reason }) => reason);

      const hasFailedProcesses = failedResults.length > 0;

      return onSuccess({
        entitlementsToRemove,
        hasFailedProcesses,
        ...(hasFailedProcesses && { failedResults }),
      });
    } catch (error) {
      return onError(new CustomError({
        message: error.message,
        statusCode: StatusCode.InternalServerError,
        error,
      }));
    }
  };

  return handler;
};

module.exports = expirePPVWrapper;
