const { CustomError } = require('@dtvgo-be/pkg_dtv_core/helpers/customError');

const createPaymentMethodWrapper = ({
  createPaymentMethodService,
  paymentMethodsSchemas,
  config,
  commons: { enums },
}) => {
  const createPaymentMethod = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const request = JSON.parse(payload.body);

      const { error } = await paymentMethodsSchemas.validate(request);
      if (error) { throw new CustomError({ message: enums.RESPONSE_MESSAGES.INVALID_PARAMETER }); }

      const configCountry = request.billing_address.country === enums
        .RESPONSE_MESSAGES.COUNTRY_OF_BR ? config.vindicia.BR : config.vindicia.LA;

      const response = await createPaymentMethodService.createPaymentMethod(request, configCountry);

      return onSuccess(response);
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    createPaymentMethod,
  };
};

module.exports = createPaymentMethodWrapper;
