const giftCardRedeemWrapper = ({
  giftCardRedeemValidationSchema,
  vindiciaGrantCreditService,
  giftCardRedeemService,
  giftCardCancelService,
  giftCardAuthService,
  giftCardStatusDGoRecorder,
  responseCodes,
  config,
  repository,
  db,
  crypto,
  commons: { enums },
  helpers,
  CustomError,
  StatusCode,
}) => {
  const redeem = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    const grantCreditPayload = JSON.parse(payload.body);

    try {
      const { headers: { Authorization } } = payload;

      const { decodedToken, configCountry } = await helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      const { error } = await giftCardRedeemValidationSchema.validate(grantCreditPayload);

      if (error) {
        error.statusCode = enums.RESPONSE_MESSAGES.STATUS_CODE_400;
        throw error;
      }

      grantCreditPayload.vindiciaId = decodedToken.customerId;
      grantCreditPayload.transactionId = crypto.randomUUID();

      await giftCardStatusDGoRecorder
        .recorderGiftCard(
          grantCreditPayload,
          config.mongodb,
          repository,
          db,
        );

      grantCreditPayload.auth = await giftCardAuthService.auth(config.incomm, config.mongodb, repository, db);
      const redeemed = await giftCardRedeemService.redeemGiftCard(grantCreditPayload, config.incomm, responseCodes);

      await giftCardStatusDGoRecorder
        .recorderGiftCard(
          grantCreditPayload,
          config.mongodb,
          repository,
          db,
          redeemed,
        );

      const result = await vindiciaGrantCreditService.postGrantCredit(
        grantCreditPayload.vindiciaId,
        {
          object: enums.REQUEST_PARAMS.VINDICIA_OBJECT_CURRENCY_AMOUNT,
          currency: grantCreditPayload.currency,
          amount: grantCreditPayload.amount,
          description: grantCreditPayload.giftCardNumber,
          reason: config.vindicia.config.reasonToCredit,
        },
        configCountry,
      );


      return onSuccess(result);
    } catch (errorCatch) {

      if (grantCreditPayload.auth) {
        try {
          grantCreditPayload.responseText = errorCatch?.message;
          await giftCardStatusDGoRecorder
            .recorderGiftCard(
              grantCreditPayload,
              config.mongodb,
              repository,
              db,
            );

          await giftCardCancelService.cancelGiftCard(grantCreditPayload, config.incomm, responseCodes);
        } catch (error) {
          return onError(errorCatch);
        }
      }
      return onError(errorCatch);
    }
  };
  return {
    redeem,
  };
};

module.exports = giftCardRedeemWrapper;
