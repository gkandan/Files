const updatePaymentMethodWrapper = ({
  updatePaymentMethodService,
  updateAccountService,
  updateCreditCardSchemas,
  config,
  helpers,
  commons: { enums },
  CustomError,
  StatusCode,
}) => {
  const shouldUpdateFederalTaxId = (federalTaxId, countryCode) => federalTaxId && [enums.COUNTRY_CODES.BR].includes(countryCode);

  const updatePaymentMethod = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const { Authorization } = payload.headers;
      const request = JSON.parse(payload.body);

      const { error } = await updateCreditCardSchemas.validate(request);
      if (error) {
        throw new CustomError({ message: enums.RESPONSE_MESSAGES.INVALID_PARAMETER, statusCode: 404 });
      }

      const { decodedToken, configCountry } = await helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      const {
        federalTaxId,
        payment_methods: { data: [{ vid, id }] },
      } = request;

      const { customerId, iso2Code: countryCode } = decodedToken;

      if (shouldUpdateFederalTaxId(federalTaxId, countryCode)) {
        const metadata = {
          [enums.VINDICIA_CUSTOM_TAGS[countryCode].FEDERAL_TAX_ID]: federalTaxId,
        };
        await updateAccountService.updateCustomFields(customerId, metadata, configCountry);
      }

      const data = {
        id: customerId,
        payment_methods: {
          data: [
            {
              object: enums.RESPONSE_MESSAGES.TYPE_OBJECT,
              vid,
              id,
              type: enums.RESPONSE_MESSAGES.PAYMENT_METHOD_CREDIT_CARD_TYPE,
            },
          ],
        },
      };

      const updatePaymentMethodInAccount = await updatePaymentMethodService
        .updatePaymentMethod(customerId, data, configCountry);

      updatePaymentMethodInAccount.object = enums.RESPONSE_MESSAGES.SUCCESSFULLY_CHANGED;
      return onSuccess(updatePaymentMethodInAccount);
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    updatePaymentMethod,
  };
};

module.exports = updatePaymentMethodWrapper;
