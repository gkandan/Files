const magentoGrantCreditWrapper = ({
  magentoGrantCreditSchema,
  magentoGrantCreditService,
  commons: { enums },
}) => {
  const grantCredit = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const partnerPayload = JSON.parse(payload.body);

      const { error } = magentoGrantCreditSchema.validate(partnerPayload);
      if (error) {
        error.statusCode = enums.RESPONSE_MESSAGES.STATUS_CODE_400;
        throw error;
      }
      const store = payload.pathParameters.country;
      const result = await magentoGrantCreditService.grantCredit(partnerPayload, store);

      return onSuccess(result);
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    grantCredit,
  };
};

module.exports = magentoGrantCreditWrapper;
