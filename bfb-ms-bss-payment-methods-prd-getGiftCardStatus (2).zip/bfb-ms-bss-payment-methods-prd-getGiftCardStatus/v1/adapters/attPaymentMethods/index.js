const { CustomError } = require('@dtvgo-be/pkg_dtv_core/helpers/customError');

const attPaymentMethodsWrapper = ({
  attPaymentMethodsSchemas,
  attPaymentMethodsService,
  config,
  commons: { enums },
}) => {
  const attPaymentMethods = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    const configCountry = config.vindicia.LA;
    try {

      const reqBody = JSON.parse(payload.body);
      const { error } = await attPaymentMethodsSchemas.validate(reqBody);
      if (error) {
        throw new CustomError({ message: enums.RESPONSE_MESSAGES.INVALID_PARAMETER });
      }

      let paymentTimespan = reqBody.telephoneNumber;

      if (reqBody.paymentIdTimespan === true) {
        paymentTimespan = `${reqBody.telephoneNumber}_map_${new Date().getTime()}`;
      }

      const bodyPaymentMethod = {
        object: enums.RESPONSE_MESSAGES.TYPE_OBJECT,
        type: enums.RESPONSE_MESSAGES.TYPE_PAYMENT_METHOD,
        merchant_accepted_payment: {
          currency: enums.RESPONSE_MESSAGES.CURRENCY,
          amount: reqBody.amount,
          payment_type: enums.RESPONSE_MESSAGES.PAYMENT_TYPE,
          payment_id: paymentTimespan,
          note: `${enums.RESPONSE_MESSAGES.NOTE} ${reqBody.telephoneNumber}`,
        },
        billing_address: {
          country: enums.RESPONSE_MESSAGES.COUNTRY,
          phone: reqBody.telephoneNumber,
        },
        policy: {
          validate: 0,
        },
      };

      const res = await attPaymentMethodsService.attPaymentMethods(
        bodyPaymentMethod,
        configCountry,
      );
      return onSuccess(res);
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    attPaymentMethods,
  };

};

module.exports = attPaymentMethodsWrapper;
