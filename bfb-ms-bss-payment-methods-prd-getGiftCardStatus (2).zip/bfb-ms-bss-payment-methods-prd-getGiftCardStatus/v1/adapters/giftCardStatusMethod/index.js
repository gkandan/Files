const { CustomError } = require('@dtvgo-be/pkg_dtv_core/helpers/customError');

const giftCardStatusWrapper = ({
  giftCardValidationSchema,
  giftCardStatusService,
  giftCardAuthService,
  giftCardStatusDGoValidator,
  responseCodes,
  upcMap,
  repository,
  db,
  config,
  crypto,
  commons: { enums },
}) => {
  const giftCardStatus = async ({ payload, onSuccess, onError }) => {
    try {
      const partnerPayload = JSON.parse(payload.body);
      const country = payload.pathParameters.country;
      let result;
      const { error } = await giftCardValidationSchema.validate(partnerPayload);

      if (error) {
        error.statusCode = enums.RESPONSE_MESSAGES.STATUS_CODE_400;
        throw error;
      }

      result = await giftCardStatusDGoValidator.validateGiftCard(
        partnerPayload.giftCardNumber,
        config.mongodb,
        repository,
        db,
      );

      if (result) return onSuccess(result);

      partnerPayload.transactionId = crypto.randomUUID();

      partnerPayload.auth = await giftCardAuthService.auth(
        config.incomm,
        config.mongodb,
        repository,
        db,
      );

      result = await giftCardStatusService.validateGiftCard(
        partnerPayload,
        config.incomm,
        responseCodes,
      );

      if (
        !upcMap[country].includes(
          result.RetailTransactionTVResponse.productResp.inventoryRespInfo.upc,
        )
      ) {
        throw new CustomError({
          message: enums.RESPONSE_MESSAGES.GIFT_CARD_NOT_BELONG_COUNTRY,
          statusCode: enums.RESPONSE_MESSAGES.STATUS_CODE_400,
        });
      }

      return onSuccess(result);
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };

  return {
    giftCardStatus,
  };
};

module.exports = giftCardStatusWrapper;
