const consultPaymentMethodsWrapper = ({
  consultPaymentMethodsBRService,
  helpers,
  config,
  commons: { enums },
  CustomError,
  StatusCode,
}) => {
  const consultPaymentMethodsBR = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const { Authorization } = payload.headers;

      const { decodedToken, configCountry } = await helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      const getPaymentMethodByAccount = await consultPaymentMethodsBRService
        .getPaymentMethodInAccount(decodedToken.customerId, configCountry);

      const arrayOfPaymentMethods = getPaymentMethodByAccount.payment_methods?.data.reduce((arr, paymentMethod) => {
        if ((paymentMethod.active === true) && (paymentMethod.primary === true)) {
          arr.push({
            billingAddress: paymentMethod.billing_address,
            vid: paymentMethod.vid,
          });
        }
        return arr;
      }, []);

      if (!arrayOfPaymentMethods || !arrayOfPaymentMethods.length) {
        return onError({
          message: enums.RESPONSE_MESSAGES.WITHOUT_PRIMARY_CREDIT_CARD,
          statusCode: 404,
        });
      }

      return onSuccess(arrayOfPaymentMethods);
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    consultPaymentMethodsBR,
  };
};

module.exports = consultPaymentMethodsWrapper;
