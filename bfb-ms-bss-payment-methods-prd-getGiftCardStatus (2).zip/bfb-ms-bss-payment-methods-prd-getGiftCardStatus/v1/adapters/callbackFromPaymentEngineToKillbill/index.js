const callbackFromPaymentEngineToKillbillWrapper = ({
  enums,
  config,
  secretManager,
  CustomError,
  callbackFromPaymentEngineToKillbillSchema,
  helpers,
  killBillService,
}) => {
  const getCountryFromOrigin = origin => origin.split('_').slice(-1).join().toUpperCase();

  const callbackFromPaymentEngineToKillbill = async ({ payload, onSuccess, onError }) => {
    try {
      const payloadKillbill = JSON.parse(payload.body);

      const { error } = callbackFromPaymentEngineToKillbillSchema.validate(payloadKillbill);
      if (error) {
        throw new CustomError({
          message: `${enums.KILLBILL_ERROR_MESSAGES.VALIDATION_ERROR} ${error?.stack}`,
          error: error?.stack,
          statusCode: 400,
        });
      }

      const country = getCountryFromOrigin(payloadKillbill.origin);

      const killBillCredentials = await helpers.getKillBillConfigByCountry({ config, secretManager, country });

      const killbillResponse = await killBillService.paymentCallback(payloadKillbill, killBillCredentials);

      return onSuccess(killbillResponse);
    } catch (error) {
      return onError(error);
    }
  };
  return {
    callbackFromPaymentEngineToKillbill,
  };
};

module.exports = callbackFromPaymentEngineToKillbillWrapper;
