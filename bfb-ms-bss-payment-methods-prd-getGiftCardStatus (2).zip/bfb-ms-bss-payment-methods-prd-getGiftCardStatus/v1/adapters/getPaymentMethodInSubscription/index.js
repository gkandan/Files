const cardType = require('../../../commons/utils/checkTypeOfCard/cardType');

const getPaymentMethodWrapper = ({
  getPaymentMethodService,
  helpers,
  config,
  commons: { enums },
  CustomError,
  StatusCode,
}) => {
  const getPaymentMethod = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    try {
      const { Authorization } = payload.headers;

      const { decodedToken, configCountry } = await helpers
        .decryptToken(Authorization, config, enums, CustomError, StatusCode);

      const creditCard = await getPaymentMethodService
        .getPaymentMethodSubscription(decodedToken.customerId, configCountry);

      const cardPrimary = creditCard.data.find(card => card.payment_method?.primary === true);

      if (cardPrimary) {
        const checkTypeOfCard = cardType(cardPrimary.payment_method?.credit_card?.bin);
        const response = {
          last4digits: cardPrimary.payment_method.credit_card.last_digits,
          bin: cardPrimary.payment_method.credit_card?.bin,
          cardType: checkTypeOfCard,
        };
        return onSuccess(response);
      }

      return onError({
        message: enums.RESPONSE_MESSAGES.WITHOUT_PRIMARY_CREDIT_CARD,
        statusCode: 404,
      });
    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    getPaymentMethod,
  };
};

module.exports = getPaymentMethodWrapper;
