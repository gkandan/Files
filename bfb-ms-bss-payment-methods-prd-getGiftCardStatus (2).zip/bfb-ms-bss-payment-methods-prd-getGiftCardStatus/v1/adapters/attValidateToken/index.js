const { CustomError } = require('@dtvgo-be/pkg_dtv_core/helpers/customError');

const attValidateTokenWrapper = ({
  attValidateTokenService,
  attCheckExternalIdService,
  attValidateTokenSchemas,
  config,
  commons: { enums },
}) => {
  const attValidateToken = async ({
    payload,
    onSuccess,
    onError,
  }) => {
    const configCountry = config.vindicia.LA;
    try {

      const body = JSON.parse(payload.body);
      const { error } = await attValidateTokenSchemas.validate(body);
      if (error) { throw new CustomError({ message: enums.RESPONSE_MESSAGES.INVALID_PARAMETER }); }

      const bodyFormatValidate = {
        validateSMSTokenRequest: {
          token: body.token,
          sourceChannel: enums.RESPONSE_MESSAGES.SOURCE_CHANNEL,
          telephoneNumber: body.telephoneNumber,
        },
      };

      const resValidateToken = await attValidateTokenService
        .attValidateToken(bodyFormatValidate, config.attmx);

      if (typeof resValidateToken.validateSMSTokenResponse === 'undefined') {
        throw new CustomError({
          message: enums.RESPONSE_MESSAGES.RESPONSE_UNDEFINED,
          statusCode: 400,
        });
      }

      if (resValidateToken.validateSMSTokenResponse.responseMessage === enums.RESPONSE_MESSAGES.INVALID_OR_EXPIRED_TOKEN
        || resValidateToken.validateSMSTokenResponse.responseMessage === enums.RESPONSE_MESSAGES.INVALID_REQUEST) {
        throw new CustomError({
          message: `${resValidateToken.validateSMSTokenResponse.responseMessage}`,
          errorCode: resValidateToken.validateSMSTokenResponse.responseCode,
          statusCode: 401,
        });
      }

      if (resValidateToken.validateSMSTokenResponse.responseMessage === enums.RESPONSE_MESSAGES.SUCCESS) {
        const externalid = resValidateToken.validateSMSTokenResponse.referenceId;

        const resValidateExternalId = await attCheckExternalIdService
          .attCheckExternalId(externalid, configCountry);

        if (resValidateExternalId.message === enums.RESPONSE_MESSAGES.STATUS_NOT_FOUND
          && resValidateExternalId.response.data.message.includes(enums.RESPONSE_MESSAGES.NO_ACCOUNT_MATCHES)) {
          return onSuccess({
            message: enums.RESPONSE_MESSAGES.USER_READY_TO_CREATE,
            external_id: externalid,
            freeToUseStatus: true,
          });
        }

        if (resValidateExternalId.object === enums.RESPONSE_MESSAGES.ACCOUNT) {
          return onSuccess({
            message: enums.RESPONSE_MESSAGES.USER_ALREADY_EXISTS,
            freeToUseStatus: false,
          });
        }

        throw new CustomError({
          resValidateToken,
          message: enums.RESPONSE_MESSAGES.INTERNAL_SERVER_ERROR,
          statusCode: 500,
        });
      }

      throw new CustomError({
        resValidateToken,
        message: enums.RESPONSE_MESSAGES.INTERNAL_SERVER_ERROR,
        statusCode: 500,
      });

    } catch (errorCatch) {
      return onError(errorCatch);
    }
  };
  return {
    attValidateToken,
  };

};

module.exports = attValidateTokenWrapper;
