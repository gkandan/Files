require('dotenv').config();

const controller = require('./v2/controllers');

module.exports = controller;
